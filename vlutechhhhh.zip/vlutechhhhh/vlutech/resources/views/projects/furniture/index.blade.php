<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>vlutech web solutions</title>
	<!-- Internal links -->
	<!-- File -->
	<link rel="stylesheet" type="text/css" href="{{asset('project_assets/furniture/css/main.css')}}">
	<link rel="stylesheet" type="text/css" href="{{asset('project_assets/furniture/css/responsive.css')}}">
	<!-- external link -->
	<!-- fontawasome cdn -->
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<!-- google fonts -->
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css2?family=Lobster&family=Poppins:ital@1&display=swap">
	<!-- Fav icon -->
   <link rel="shortcut icon" type="{{asset('project_assets/furniture/image/png')}}" href="fav.jpg">
   <!-- aos animation on scroll -->
     <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
</head>
<body>
	<section class="home" id="top-banner" style="background-image: linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)), url(img3.jpg); background-size: cover; background-position: center;">
		<header>
			<div id="logo">
				<h1 data-aos="flip-up">vlutech</h1>
			</div>
			<nav id="navbar">

				<ul>
					<i class="fa fa-times" id="cross" onclick="closeNav()"></i>
					<li><a href="#top-banner">home</a></li>
					<li><a href="#srv">services</a></li>
					<li><a href="#prdt">products</a></li>
					<li><a href="#testimonial">testimonials</a></li>
					<li><a href="#con">contact</a></li>
					<li><a href="#"><i class="fa fa-shopping-bag" id="bag"></i></a></li>
				</ul>
			</nav>
			<div class="toggler">
				<i class="fa fa-bars" id="bars" onclick="openNav()"></i>
			</div>
		</header>
		<div class="banner-text">
			<h1>Feel The Beauty Of Our Furnitures !</h1>
			<p>Best Quality Product With Best Service.</p>
			<a href="#">Order Now</a>
		</div>
	</section>
	<!-- services section -->
	<section class="service" id="srv">
		<div class="main_content">
			<h1>Our Services</h1>
			<p>The best furniture you can find on the planet!</p>
		</div>
		<div class="cards">
			<div class="card">
				<i class="fa fa-truck" aria-hidden="true"></i>
				<h1>Fastest Delivery</h1>
				<p>We provide you the best deilivery network.</p>
			</div>
			<div class="card">
				<i class="fa fa-usd" aria-hidden="true"></i>
				<h1>Best Price</h1>
				<p>We provide you the best price with best quality.</p>
			</div>
			<div class="card">
				<i class="fa fa-question-circle" aria-hidden="true"></i>
				<h1>Your Questions</h1>
				<p>We clear all of your doubts within 24 hrs.</p>
			</div>
	</section>
	<!-- Products sectio -->
	<section class="product" id="prdt">
		<div class="product_main_text">
			<h1>Products</h1>
			<p>We provide you the <b>Number one</b> product.</p>
		</div>
		<div class="product_cards">
			<div class="products">
				<img src="{{asset('project_assets/furniture/sofa.png')}}">
				<div class="lines">
				<h1>Sofas</h1>
				<p>We provide you the best sofas around the world you have ever seen.</p>
				<a href="#">See</a>	
				</div>
			</div>
			<hr>
			<div class="products">
				<img src="{{asset('project_assets/furniture/bed.png')}}">
				<div class="lines">
				<h1>Beds</h1>
				<p>We provide you the best beds around the world you have ever seen.</p>
				<a href="#">See</a>	
				</div>				
			</div>
			<hr>
			<div class="products">
				<img src="{{asset('project_assets/furniture/table.png')}}">
				<div class="lines">
				<h1>Tables</h1>
				<p>We provide you the best sofas around the world you have ever seen.</p>
				<a href="#">See</a>	
				</div>
			</div>
			<hr>
			</div>
		</div>
	</section>

	<!-- testimonials -->
	<section class="testimonials" id="testimonial">
		<div class="testi_text">
			<h1>Testimonials</h1>
			<p>Free to write your own reviews.</p>
		</div>
		<div class="reviews">
			<div class="revw_card">
				<img src="{{asset('project_assets/furniture/girl.png')}}" class="image">
				<h1>Lora</h1>
				<p>I loved its dressing table, its truly amazing.</p>
			</div>

			<div class="revw_card">
				<img src="{{asset('project_assets/furniture/man.png')}}" class="image">
				<h1>Mr.Stark</h1>
				<p>Its amazing to purchase various furnitures from here as the quality and cost is very much effective.</p>
			</div>

			<div class="revw_card">
				<img src="{{asset('project_assets/furniture/boy.png')}}" class="image">
				<h1>Harris</h1>
				<p>Really its service is best than any other.</p>
			</div>
		</div>
	</section>

	<!-- contact footer -->
	<section class="contact" id="con">
		<footer>
			<div class="footerdivs">
				<h1>Royal</h1>
			</div>
			<div class="footerdivs">
				<a href="#top-banner">home</a>
				<a href="#srv">services</a>
				<a href="#prdt">products</a>
				<a href="#testimonial">testimonials</a>
				<a href="#">contact</a>
			</div>
			<div class="footerdivs">
				<i class="fa fa-facebook" aria-hidden="true"></i>
				<i class="fa fa-twitter" aria-hidden="true"></i>
				<i class="fa fa-linkedin" aria-hidden="true"></i>
				<i class="fa fa-instagram" aria-hidden="true"></i>
				<i class="fa fa-youtube" aria-hidden="true"></i>
			</div>
		</footer>
		<div class="copyright">
			<h2>@Copyright Vlutech</h2>
		</div>
	</section>
	<!-- scripts -->
<script src="{{asset('project_assets/furniture/script/main.js')}}"></script>
<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
  <script>
    AOS.init({
    	duration: 1000,
    	delay: 100
    });
  </script>
</body>
</html>
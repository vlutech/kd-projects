<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery-3.5.1.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <title>Vlutech Web Solutions</title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  
  <link href="assets/css/style.css" rel="stylesheet">
  
</head>

<body>

  
 

    
    <!-- ======= Contact Section ======= -->
    <section id="contact" class="paralax-mf footer-paralax bg-image sect-mt4 route mfffa">
      <div class="overlay-mf"></div>
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="contact-mf">
              <div id="contact" class="box-shadow-full">
                <div class="row">
                  <div class="col-md-6">
                    <div class="title-box-2">
                      <h5 class="title-left">
                        Send Message Us
                      </h5>
                    </div>
                    <div>
                      
                      
                      <form action="" method="post" role="form">
                          <input type="text" name="name" placeholder="name" class="form-control hlwworld"><br><br>
                          <input type="text" name="email" placeholder="email" class="form-control hlwworld"><br><br>
                          <input type="text" name="phone" placeholder="phone" class="form-control hlwworld"><br><br>
                          <textarea name="message" placeholder="message" class="form-control hlwworld"></textarea><br><br>
                          <input type="submit" name="submit" value="send" class="hlwworld1" style="color:white;font-weight:500;">
                      </form>
                      
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="title-box-2 pt-4 pt-md-0">
                      <h5 class="title-left">
                        Get in Touch
                      </h5>
                    </div>
                    <div class="more-info">
                      <p class="lead leaderss">
                    We love to hear from you Call or Email, 
                    we respond as soon as possible
                   
                      </p>
                      <ul class="list-ico">
                        <li><span class="bi bi-geo-alt" style="font-size:30px;"></span> 295 M BLOCK SECTOR 1 BAWANA DELHI</li>
                        <li><span class="bi bi-phone" style="font-size:30px;"></span> +917701906734</li>
                        <li><span class="bi bi-envelope" style="font-size:30px;"></span>info@vlutech.com</li>
                      </ul>
                    </div>
                    <div class="socials">
                      <ul>
                        <li><a href="https://www.facebook.com/"><span class="ico-circle"><i class="bi bi-facebook"></i></span></a></li>
                        <li><a href="https://www.instagram.com/"><span class="ico-circle"><i class="bi bi-instagram"></i></span></a></li>
                        <li><a href="https://www.twitter.com/"><span class="ico-circle"><i class="bi bi-twitter"></i></span></a></li>
                        <li><a href="https://www.linkedin.com/"><span class="ico-circle"><i class="bi bi-linkedin"></i></span></a></li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer>
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="copyright-box">
            <p class="copyright">&copy; Copyright <strong>VLUTECH WEB SOLUTIONS</strong>. All Rights Reserved</p>
            <div class="credits">
             
              Designed by <a href="https://vlutech.com/">VLUTECH WEB SOLUTIONS</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer><!-- End  Footer -->

 
  <script src="assets/js/main.js"></script>

</body>

</html>





@extends('front-view.header')

<section id="blog" class="blog-mf sect-pt4 route">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="title-box text-center">
              <h3 class="title-a">
                Blog
              </h3>
              <p class="subtitle-a">
                We will inform you about all new technology
              </p>
              <div class="line-mf"></div>
            </div>
          </div>
        </div>
        <div class="row">
        @foreach($blogs as $list)

          <div class="col-md-12">
            <div class="card card-blog">
              <div class="card-img">
                <a href="{{asset('img/'.$list->image)}}"><img src="{{asset('img/'.$list->image)}}" alt="" class="img-fluid"></a>
              </div>
              <div class="card-body">
                <div class="card-category-box">
                  <div class="card-category">
                    <h6 class="category">{{$list->Title}}</h6>
                  </div>
                </div>
                <h3 class="card-title"><a href="">See more ideas about {{$list->Title}}</a></h3>
                <p class="card-description justify" style="font-size: 20px;">
                {{$list->description}}
                </p>
              </div>
              <div class="card-footer">
                <div class="post-author">
                  <a href="{{asset('img/testimonial-2.jpg')}}">
                    <!--<img src="assets/img/testimonial-2.jpg" alt="" class="avatar rounded-circle">-->
                    <span class="author">Vlutech Web Solutions</span>
                  </a>
                </div>
                <div class="post-date">
                  <span class="bi bi-clock"></span> 30 min
                </div>
              </div>
            </div>
          </div>
          @endforeach
          {{$blogs->links('pagination::bootstrap-4')}}
          </div>
      </div>
    </section><!-- End Blog Section -->
    


    @extends('front-view.footer')
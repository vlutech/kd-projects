@extends('admin/layout')
@section('page_title','Footer')
@section('footer_select','active')
@section('container')



<h1 class="mb10">Footer</h1>
<a href="{{url('admin/footer/manage_footer')}}">
    <button type="button" class="btn btn-success"> Add Footer</button>
</a>
<div class="row m-t-30">
        <div class="col-md-12 col-sm-12">
            <!-- DATA TABLE-->
            <div class="table-responsive m-b-40">
                <table class="table table-borderless table-data3">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>menu</th>
                            <th>discount</th>
                            <th>offer</th>
                            <th>site_map</th>
                            <th>suppliers</th>
                            <th>faq</th>
                            <th>address</th>
                            <th>mobile</th>
                            <th>email</th>
                            <th>links</th>
                            <th>action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($data as $list)
                        <tr>
                            <td>{{$list->id}}</td>
                            <td>{{$list->menu}}</td>
                            <td>{{$list->discount}}</td>
                            <td>{{$list->offer}}</td>
                            <td>{{$list->site_map}}</td>
                            <td>{{$list->suppliers}}</td>
                            <td>{{$list->faq}}</td>
                            <td>{{$list->address}}</td>
                            <td>{{$list->mobile}}</td>
                            <td>{{$list->email}}</td>
                            <td>{{$list->links}}</td>
                            <td>
                                <a href="{{url('admin/footer/manage_footer/')}}/{{$list->id}}">
                                    <button type="button" class="btn btn-info">Edit</button>
                                </a>
                                @if($list->status==1)
                                <a href="{{url('admin/footer/status/0')}}/{{$list->id}}">
                                    <button type="button" class="btn btn-success">
                                        <i class="fa fa-check" aria-hidden="true"></i>
                                    </button>
                                </a>
                                @elseif($list->status==0)
                                <a href="{{url('admin/footer/status/1')}}/{{$list->id}}">
                                    <button type="button" class="btn btn-warning">
                                        <i class="fa fa-times" aria-hidden="true"></i>
                                    </button>
                                </a>
                                @endif
                                <a href="{{url('admin/footer/delete/')}}/{{$list->id}}">
                                    <button type="button" class="btn btn-danger">Delete</button>
                                </a>
                            </td>
                        </tr>
                        @endforeach
                        
                    </tbody>
                </table>
            </div>
            <!-- END DATA TABLE-->
        </div>
    </div>

    @if(session()->has('message'))
<script>
       
iziToast.info({
    timeout: 5000,
    overlay: false,
    displayMode: 'once',
    id: 'inputs',
    zindex: 1,
    title: "<h3 class='text-danger'>Alert-:</h3>",
    message: "<h3 class='text-success'>{{session('message')}}</h3>",
    position: 'center',
    drag: true,
    // inputs: [
    //     ['<input type="checkbox">', 'change', function (instance, toast, input, e) {
    //         console.info(input.checked);
    //     }],
    //     ['<input type="text">', 'keyup', function (instance, toast, input, e) {
    //         console.info(input.value);
    //     }, true],
    //     ['<input type="number">', 'keydown', function (instance, toast, input, e) {
    //         console.info(input.value);
    //     }],
    // ]
});
       
    </script>
    @endif

@endsection
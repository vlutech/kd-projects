<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- Title Page-->
    <title>@yield('page_title')</title>
    <link rel="stylesheet" href="{{asset('admin_assets/css/iziToast.min.css')}}">
    <script src="{{asset('admin_assets/js/iziToast.min.js')}}" type="text/javascript"></script>
    <!-- Fontfaces CSS-->
    <link href="{{asset('admin_assets/css/font-face.css')}}" rel="stylesheet" media="all">
    <link href="{{asset('admin_assets/vendor/font-awesome-4.7/css/font-awesome.min.css')}}" rel="stylesheet" media="all">
    <link href="{{asset('admin_assets/vendor/font-awesome-5/css/fontawesome-all.min.css')}}" rel="stylesheet" media="all">
    <link href="{{asset('admin_assets/vendor/mdi-font/css/material-design-iconic-font.min.css')}}" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="{{asset('admin_assets/vendor/bootstrap-4.1/bootstrap.min.css')}}" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="{{asset('admin_assets/vendor/animsition/animsition.min.css')}}" rel="stylesheet" media="all">
    <link href="{{asset('admin_assets/vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css')}}" rel="stylesheet" media="all">
    <link href="{{asset('admin_assets/vendor/wow/animate.css')}}" rel="stylesheet" media="all">
    <link href="{{asset('admin_assets/vendor/css-hamburgers/hamburgers.min.css')}}" rel="stylesheet" media="all">
    <link href="{{asset('admin_assets/vendor/slick/slick.css')}}" rel="stylesheet" media="all">
    <link href="{{asset('admin_assets/vendor/select2/select2.min.css')}}" rel="stylesheet" media="all">
    <link href="{{asset('admin_assets/vendor/perfect-scrollbar/perfect-scrollbar.css')}}" rel="stylesheet" media="all">



    <script src="iziToast.min.js" type="text/javascript"></script>
    <!-- Main CSS-->
    <link href="{{asset('admin_assets/css/theme.css')}}" rel="stylesheet" media="all">
    <link href="{{asset('admin_assets/css/reviewtheme.css')}}" rel="stylesheet" media="all">
<style>
    hr{margin-top:3px;margin-bottom:3px; background: grey;opacity:.3;}
    .navbar-mobile ul li{font-size: 10px !important;}
    .navbar-mobile .header-mobile__bar{height: 50px;}
</style>
</head>

<body>
   
<div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <header class="header-mobile d-block d-lg-none">
            <div class="header-mobile__bar">
                <div class="container-fluid">
                    <div class="header-mobile-inner">
                        <a class="logo" href="index.html">
                        <img src="{{asset('admin_assets/images/icon/logo1111.png')}}" alt="Cool Admin" / style="width:100%;">
                        </a>
                        <button class="hamburger hamburger--slider" type="button">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <nav class="navbar-mobile">
                <div class="container-fluid">
                    <ul class="navbar-mobile__list list-unstyled"style="font-size: 5px !important;">
                    <li class="@yield('banner_select')">
                            <a href="{{url('admin/dashboard')}}">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                        </li>
                        <li class="@yield('banner_select')">
                            <a href="{{url('admin/banner')}}">
                            <i class="fas fa-sliders"></i>Banner</a>
                        </li>   <hr> 
                        <li class="@yield('services_select')">
                            <a href="{{url('admin/services')}}">
                            <i class="fas fa-sliders"></i>services</a>
                        </li>   <hr> 
                        <li class="@yield('product_select')">
                            <a href="{{url('admin/product/product')}}">
                            <i class="fas fa-sliders"></i>Product</a>
                        </li>   <hr> 
                        <li class="@yield('testimonial_select')">
                            <a href="{{url('admin/testimonial')}}">
                            <i class="fas fa-cart-plus"></i>Testimonials</a>
                        </li>   <hr>
                        <li class="@yield('blog_select')">
                            <a href="{{url('admin/blog')}}">
                            <i class="fas fa-cart-plus"></i>Blogs</a>
                        </li>   <hr>
                        <li class="@yield('orderdetail_select')">
                            <a href="{{url('admin/orderdetail')}}">
                            <i class="fas fa-cart-plus"></i>Order Details</a>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>
        <!-- END HEADER MOBILE-->

        <!-- MENU SIDEBAR-->
        <aside class="menu-sidebar d-none d-lg-block" style=" overflow:visible;">
            <div class="logo" style="width:100%;">
                <a href="#" style="width:50%;margin-left:10%;">
                    <img src="{{asset('admin_assets/images/icon/logo1111.png')}}" alt="Cool Admin" / style="width:100%;">
                </a>
            </div> <!--<hr style="background: white;margin-top:0;padding-top:0; width:70%;"> -->
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li class="@yield('dashboard_select')">
                            <a href="{{url('admin/dashboard')}}">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                        </li> 
                        <li class="@yield('banner_select')">
                            <a href="{{url('admin/banner')}}">
                            <i class="fas fa-sliders"></i>Banner</a>
                        </li>   
                        <div class="@yield('services_select')">
                        <li>
                            <a href="{{url('admin/service')}}">
                            <i class="fas fa-sliders"></i>services</a>
                        </li>   
                        </div>
                        <li class="@yield('project_select')">
                            <a href="{{url('admin/project')}}">
                            <i class="fas fa-sliders"></i>Project</a>
                        </li>   
                        <li class="@yield('testimonial_select')">
                            <a href="{{url('admin/testimonial')}}">
                            <i class="fas fa-cart-plus"></i>Testimonials</a>
                        </li>  
                        <li class="@yield('blog_select')">
                            <a href="{{url('admin/blog')}}">
                            <i class="fas fa-cart-plus"></i>Blogs</a>
                        </li>   
                        <li class="@yield('orderdetail_select')">
                            <a href="{{url('admin/orderdetail')}}">
                            <i class="fas fa-cart-plus"></i>Order Details</a>
                        </li> 
                    </ul>
                </nav>
            </div>
        </aside>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <header class="header-desktop" style="background: rgba(0, 0, 0, 1);">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="header-wrap">
                            <form class="form-header" action="" method="POST">
                                
                            </form>
                            <div class="header-button">
                                <div class="noti-wrap">    
                                </div>
                                <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu">
                                        <div class="image">
                                            <img src="{{asset('admin_assets/images/icon/avatar-01.jpg')}}" alt="John Doe" />
                                        </div>
                                        <div class="content">
                                            <a class="js-acc-btn" href="#">Welcome Admin</a>
                                        </div>
                                        <div class="account-dropdown js-dropdown">
                                            
                                            <div class="account-dropdown__body">
                                                <div class="account-dropdown__item">
                                                    <a href="#">
                                                        <i class="zmdi zmdi-account"></i>Account</a>
                                                </div>
                                                <!-- <div class="account-dropdown__item">
                                                    <a href="#">
                                                        <i class="zmdi zmdi-settings"></i>Setting</a>
                                                </div>
                                                <div class="account-dropdown__item">
                                                    <a href="#">
                                                        <i class="zmdi zmdi-money-box"></i>Billing</a>
                                                </div> -->
                                            </div>
                                            <div class="account-dropdown__footer">
                                                <a href="{{url('admin/logout')}}">
                                                    <i class="zmdi zmdi-power"></i>Logout</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <!-- END HEADER DESKTOP-->

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                    @section('container')
                    @show
                    </div>
                </div>
            </div>
        </div>
        <!-- END PAGE CONTAINER-->
    </div>
    <script src="iziToast.min.js" type="text/javascript"></script>
   
   
    <script src="{{asset('admin_assets/vendor/jquery-3.2.1.min.js')}}"></script>
    <script src="{{asset('admin_assets/vendor/bootstrap-4.1/popper.min.js')}}"></script>
    <script src="{{asset('admin_assets/vendor/bootstrap-4.1/bootstrap.min.js')}}"></script>
    <script src="{{asset('admin_assets/vendor/wow/wow.min.js')}}"></script>

<!-- Vendor JS       -->
<script src="{{asset('admin_assets/vendor/slick/slick.min.js')}}">
    </script>
    <script src="{{asset('admin_assets/vendor/wow/wow.min.js')}}"></script>
    <script src="{{asset('admin_assets/vendor/animsition/animsition.min.js')}}"></script>
    <script src="{{asset('admin_assets/vendor/bootstrap-progressbar/bootstrap-progressbar.min.js')}}">
    </script>
    <script src="{{asset('admin_assets/vendor/counter-up/jquery.waypoints.min.js')}}"></script>
    <script src="{{asset('admin_assets/vendor/counter-up/jquery.counterup.min.js')}}">
    </script>
    <script src="{{asset('admin_assets/vendor/circle-progress/circle-progress.min.js')}}"></script>
    <script src="{{asset('admin_assets/vendor/perfect-scrollbar/perfect-scrollbar.js')}}"></script>
    <script src="{{asset('admin_assets/vendor/chartjs/Chart.bundle.min.js')}}"></script>
    <script src="{{asset('admin_assets/vendor/select2/select2.min.js')}}">
    </script>

    <script src="{{asset('admin_assets/js/main.js')}}"></script>

</body>

</html>
<!-- end document-->
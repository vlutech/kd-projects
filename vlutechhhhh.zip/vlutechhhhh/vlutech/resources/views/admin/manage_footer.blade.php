@extends('admin/layout')
@section('page_title','Manage Footer')
@section('container')


<div class="row m-t-30">
        <div class="col-md-6 col-sm-12 offset-3">
        
        <div class="card">
           
           
            <div class="card-body">
                
                <form action="{{route('footer.manage_footer_process')}}" method="post" style="padding:30px;">
                <h1 class="mb10">Manage Footer</h1>
<a href="{{url('admin/footer')}}">
    <button type="button" class="btn btn-success"> Back</button><br><br><br>
</a>
                @csrf    
                <div class="form-group">
                        <label for="menu" class="control-label mb-1">menu</label>
                       <input id="menu" value="{{$menu}}" name="menu" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                       @error('menu')
                        <div class="alert alert-danger" role="alert">
                            {{$message}}
                        </div>
                       @enderror
                    </div>
                    <div class="form-group">
                        <label for="discount" class="control-label mb-1">discount</label>
                        <input id="discount" value="{{$discount}}" name="discount" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        @error('discount')
                        <div class="alert alert-danger" role="alert">
                            {{$message}}
                        </div>
                       @enderror
                    </div>
                    <div class="form-group">
                        <label for="offer" class="control-label mb-1">offer</label>
                        <input id="offer" value="{{$offer}}" name="offer" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        @error('offer')
                        <div class="alert alert-danger" role="alert">
                            {{$message}}
                        </div>
                       @enderror
                    </div>  
                    <div class="form-group">
                        <label for="site_map" class="control-label mb-1">site_map</label>
                        <input id="site_map" value="{{$site_map}}" name="site_map" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        @error('site_map')
                        <div class="alert alert-danger" role="alert">
                            {{$message}}
                        </div>
                       @enderror
                    </div>  
                    <div class="form-group">
                        <label for="suppliers" class="control-label mb-1">suppliers</label>
                        <input id="suppliers" value="{{$suppliers}}" name="suppliers" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        @error('suppliers')
                        <div class="alert alert-danger" role="alert">
                            {{$message}}
                        </div>
                       @enderror
                    </div>  
                    <div class="form-group">
                        <label for="faq" class="control-label mb-1">faq</label>
                        <input id="faq" value="{{$faq}}" name="faq" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        @error('faq')
                        <div class="alert alert-danger" role="alert">
                            {{$message}}
                        </div>
                       @enderror
                    </div>  
                    <div class="form-group">
                        <label for="address" class="control-label mb-1">address</label>
                        <input id="address" value="{{$address}}" name="address" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        @error('address')
                        <div class="alert alert-danger" role="alert">
                            {{$message}}
                        </div>
                       @enderror
                    </div>    
                    <div class="form-group">
                        <label for="mobile" class="control-label mb-1">mobile</label>
                        <input id="mobile" value="{{$mobile}}" name="mobile" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        @error('mobile')
                        <div class="alert alert-danger" role="alert">
                            {{$message}}
                        </div>
                       @enderror
                    </div>  
                    <div class="form-group">
                        <label for="email" class="control-label mb-1">email</label>
                        <input id="email" value="{{$email}}" name="email" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        @error('email')
                        <div class="alert alert-danger" role="alert">
                            {{$message}}
                        </div>
                       @enderror
                    </div>  
                    <div class="form-group">
                        <label for="links" class="control-label mb-1">links</label>
                        <input id="links" value="{{$links}}" name="links" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        @error('links')
                        <div class="alert alert-danger" role="alert">
                            {{$message}}
                        </div>
                       @enderror
                    </div>  
                    <div class="col-lg-4 offset-4">
                        <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">Submit</button>
                    </div>
                    <input type="hidden" name="id" value="{{$id}}"/>
                </form>
            </div>
        </div>
        </div>
    </div>


@endsection
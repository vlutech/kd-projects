@extends('admin/layout')
@section('page_title','Project')
@section('project_select','active')
@section('container')



<div>
<h1 class="" align=center>Project</h1>
<h5>{{session('name')}}</h5>
<a href="{{url('admin/project/manage_project')}}">
    <button type="button" class="btn btn-success"> Add Project </button>
</a>
<div class="row m-t-30">
        <div class="col-md-12 col-sm-12">
            <!-- DATA TABLE-->
            <div class="table-responsive m-b-40">
                <table class="table table-borderless table-data3">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>image</th>
                            <th>project_name</th>
                            <th>design_by</th>
                            <th>status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody> 
                        @foreach($data as $list)
                        <tr>
                            <td>{{$list->id}}</td>
                            <td><a href="{{asset('/img/'.$list->image)}}"><img src="{{asset('/img/'.$list->image)}}" alt=""  style="width: 100px; height:100px;" /></a></td>
                            <td>{{$list->project_name}}</td>
                            <td>{{$list->design_by}}</td>
                            <td>{{$list->status}}</td>
                            <td>
                                <a href="{{url('admin/project/manage_project/')}}/{{$list->id}}">
                                    <button type="button" class="btn btn-info">Edit</button>
                                </a>
                                @if($list->status==1)
                                <a href="{{url('admin/project/status/0')}}/{{$list->id}}">
                                    <button type="button" class="btn btn-success">
                                        <i class="fa fa-check" aria-hidden="true"></i>
                                    </button>
                                </a>
                                @elseif($list->status==0)
                                <a href="{{url('admin/project/status/1')}}/{{$list->id}}">
                                    <button type="button" class="btn btn-warning">
                                        <i class="fa fa-times" aria-hidden="true"></i>
                                    </button>
                                </a>
                                @endif
                                <a href="{{url('admin/project/delete/')}}/{{$list->id}}">
                                    <button type="button" class="btn btn-danger">Delete</button>
                                </a>
                            </td>
                        </tr>
                        @endforeach
                        
                    </tbody>
                </table>
            </div>
            <!-- END DATA TABLE-->
        </div>
    </div>

    @if(session()->has('message'))
<script>
       
iziToast.info({
    timeout: 5000,
    overlay: false,
    displayMode: 'once',
    id: 'inputs',
    zindex: 1,
    title: "<h3 class='text-danger'>Alert-:</h3>",
    message: "<h3 class='text-success'>{{session('message')}}</h3>",
    position: 'center',
    drag: true,
   
});
       
    </script>
    @endif



@endsection
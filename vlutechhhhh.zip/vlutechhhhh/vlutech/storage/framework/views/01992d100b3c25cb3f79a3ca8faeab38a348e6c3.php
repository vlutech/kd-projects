<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
  <script src="<?php echo e(asset('assets/js/jquery-3.5.1.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
  <title>Vlutech Web Solution</title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  
  
  <!-- Vendor CSS Files -->
  <link href="<?php echo e(asset('assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('assets/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('assets/vendor/glightbox/css/glightbox.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('assets/vendor/swiper/swiper-bundle.min.css')); ?>" rel="stylesheet">
  <!-- Template Main CSS File -->
  <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
   <link href="<?php echo e(asset('assets/css/portfoliostyle.css')); ?>" rel="stylesheet">
  


<style>
.whatsapp .whatsapp-chat{width:70px;height:70px;position:fixed; bottom:40px; right:0px; z-index:999;}
.input-group-text{
    background:#c0392b;
}
.cookie-container{
            position: fixed;
            bottom: -100%;
            right: 75px;
            box-shadow: 0 -2px 16px rgba(46, 54, 64);
            left: 0;background: #2f3640;color: #f5f6fa;padding: 0 32px;transition: 400ms; z-index:999;
        }
        .cookie-container.active{bottom: 0;}
        .cookie-btn{background: #e84118;border: 0;color: #f5f6fa;padding: 8px 30px;font-size: 12px;margin-bottom: 16px;border-radius: 8px;cursor: pointer;}

</style>
  
</head>

<body>
   

  <!-- ======= Header ======= -->
  

  <!-- ======= Hero Section ======= -->
  <div id="hero" class="hero route bg-image" style="background-image: url(assets/img/hero-bg.jpg)">
    <div class="overlay-itro"></div>
    <div class="hero-content display-table">
      <div class="table-cell">
        <div class="container">
          <h1 class="hero-title mb-4">Accelerating</h1>
          <h1 class="hero-title mb-4">Your</h1>
          <h1 class="hero-title mb-4">Business</h1>
          <h1 class="hero-title mb-4">Growth...</h1>
          <p class="hero-subtitle"><span class="typed" data-typed-items="App Devlopment..,Google Search Engine..,Web Devlopment.., "></span></p>
          
        </div>
      </div>
    </div>
  </div><!-- End Hero Section -->

  <main id="main">
      
      <!-- ======= Services Section ======= -->
    <section id="services" class="services-mf pt-5 route">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="title-box text-center">
              <h3 class="title-a">
                Services
              </h3>
              <p class="subtitle-a">
                Increase customers and increase revenue we will provide you good quality of Website for your business.
              </p>
              <div class="line-mf"></div>
            </div>
          </div>
        </div>
        <div class="row">
          <?php $__currentLoopData = $home_services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-4">
            <div class="service-box">
              <div class="service-ico">
                <span class="ico-circle"><i class="bi bi-briefcase"></i></span>
              </div>
              <div class="service-content">
                <h2 class="s-title"><?php echo e($list->name); ?></h2>
                <p class="s-description text-center">
                  <?php echo e($list->description); ?>

                </p>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </section>
    <!-- End Services Section -->


    <!-- ======= Project Section ======= -->
    
    <section id="work" class="portfolio-mf sect-pt4 route">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="title-box text-center">
              <h3 class="title-a">
                PROJECTS
              </h3>
              <p class="subtitle-a">
                    Last Year Projects. ...
              </p>
              <div class="line-mf"></div>
            </div>
          </div>
        </div>
        <div class="row">
          <?php $__currentLoopData = $home_projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-4">
            <div class="work-box">
              <a href="<?php echo e(asset('img/'.$list->image)); ?>" data-gallery="portfolioGallery" class="portfolio-lightbox">
                <div class="work-img">
                  <img src="<?php echo e(asset('img/'.$list->image)); ?>" alt="" class="img-fluid">
                </div>
              </a>
              <div class="work-content">
                <div class="row">
                  <div class="col-sm-8">
                    <h2 class="w-title" style="font-size:17px !important;"><?php echo e($list->project_name); ?></h2>
                    <div class="w-more">
                      <span class="w-ctegory">Design By: <?php echo e($list->design_by); ?>....</span> / <span class="w-date">Jun. 2021</span>
                    </div>
                  </div>
                  </div>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>   
      </script>
    <!-- End project Section -->


    <!-- pricing start -->
    <section id="pricing" class="pricing ccc">
      <div class="container">

        <div class="section-title">
          
          <h2>Pricing</h2>
          <!--<p>Sit sint consectetur velit quisquam cupiditate impedit suscipit alias</p>-->
        </div>

        <div class="row">

          <div class="col-lg-3 col-md-6">
            <div class="box">
              <h3>Static</h3>
              <h4><sup>&#8377;</sup>15000<span>/ year</span></h4>
              <ul>
                <li>Up to 12 pages</li>
                <li>Logo Design</li>
                <li>Up to 15 Stock Images</li>
                <li class="">Free 2 Year Hosting</li>
                <li class="">Free 1 Year Domain</li>
                <li class="">Free On Page Seo</li>
                </ul>
              <div class="btn-wrap">
                <a href="#" class="btn-buy">Buy Now</a>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-4 mt-md-0">
            <div class="box featured">
              <h3>Dynamic</h3>
              <h4><sup>&#8377;</sup>25000<span>/ year</span></h4>
              <ul>
                <li>Up to 21 pages</li>
                <li>Logo Design</li>
                <li>Up to 35 Stock Images</li>
                <li>Free 5 Year Hosting</li>
                <li class=""> Free 2 Year Domain</li>
                <li class=""> Free On Page Seo</li>
              </ul>
              <div class="btn-wrap">
                <a href="#" class="btn-buy">Buy Now</a>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-4 mt-lg-0">
            <div class="box">
              <h3>E-Commerce</h3>
              <h4><sup>&#8377;</sup>35000<span> / year</span></h4>
              <ul>
                <li>Up to 35 pages</li>
                <li>Logo Design</li>
                <li>Up to 150 Stock Images</li>
                <li>Free 5 Year Hosting</li>
                <li class=""> Free 5 Year Domain</li>
                <li>Free On Page SEO</li>
              </ul>
              <div class="btn-wrap">
                <a href="#" class="btn-buy">Buy Now</a>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-4 mt-lg-0">
            <div class="box">
              <span class="advanced">Advanced</span>
              <h3>Ultimate</h3>
              <h4><sup>&#8377;</sup>50000<span> / year</span></h4>
              <ul>
                <li>Up to 100 pages</li>
                <li>Up to 500 Stock Images</li>
                <li>Free 10 Year Hosting</li>
                <li class=""> Free 10 Year Domain</li>
                <li>Free 5 Year Social Media Marketing</li>
                <li>Free 2 Year On Page SEO</li>
              </ul>
              <div class="btn-wrap">
                <a href="#" class="btn-buy">Buy Now</a>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Pricing Section -->
    
    <!-- ======= About Section ======= -->
    
    <section id="about" class="about-mf sect-pt4 route">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="box-shadow-full">
              <div class="row">
                <div class="col-md-6">
                  <div class="row">
                    
                    <div class="col-sm-6 col-md-10">
                      <div class="about-info">
                        <p><span class="title-s">Company Name: </span> <span>Vlutech Web Solutions</span></p>
                        <p><span class="title-s">Profile: </span> <span>Dilivering innovation strategy Technology and Business consulting services.</span></p>
                        <p><span class="title-s">Email: </span> <span>info@vlutech.com</span></p>
                        <p><span class="title-s">Mr Lalit: </span> <span>+91 7701906734</span></p>
                        <p><span class="title-s">Mr Umesh: </span> <span>+91 8287178047</span></p>
                        <p><span class="title-s">Gst No: </span> <span>07GREPS9734Q1ZM</span></p>
                      </div>
                    </div>
                  </div>
                  <div class="skill-mf">
                  <p class="title-s">   </p>
                  <span>HTML</span> <span class="pull-right">98.9%</span>
                  <div class="progress">
                  <div class="progress-bar" role="progressbar" style="width: 98.9%;" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                  <span>CSS3</span> <span class="pull-right">97.8%</span>
                  <div class="progress">
                  <div class="progress-bar" role="progressbar" style="width: 97.8%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                  <span>PHP</span> <span class="pull-right">99.2%</span>
                  <div class="progress">
                  <div class="progress-bar" role="progressbar" style="width: 99.2%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="about-me pt-4 pt-md-0">
                    <div class="title-box-2">
                      <h5 class="title-left">
                        About us
                      </h5>
                    </div>
                    <p class="lead leaderss">
                      Vlutech Web Solutions company is a premium design company that focuses on quality,
                       innovations & speed. We are the top India's leading website designing company in I.T industry.
                       We utilized technology to bring results to grow our clients Businesses.
                       
                    </p>
                    <p class="lead">
                      We understand that every company has a unique requirement when it comes to web designing and marketing. We help them to meet their unique 
                      requirement and stay ahead in competition And we are in competition in the past 7 years, And because of our happy clients, we are one of the top company in Delhi.
                    <p class="lead">
                      
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section><!-- End About Section -->
    
    
 <!-- ======= Counter Section ======= -->
    <section>
    <div class="section-counter paralax-mf bg-image mfff" style="background:#504846;">
      <div class="overlay-mf overlay-mfll"></div>
      <div class="container position-relative">
        <div class="row">
          <div class="col-sm-3 col-lg-3">
            <div class="counter-box counter-box pt-4 pt-md-0">
              <div class="counter-ico">
                <span class="ico-circle"><i class="bi bi-check"></i></span>
              </div>
              <div class="counter-num">
                <p data-purecounter-start="0" data-purecounter-end="1501" data-purecounter-duration="1" class="counter purecounter"></p>
                <span class="counter-text">WORKS COMPLETED</span>
              </div>
            </div>
          </div>
          <div class="col-sm-3 col-lg-3">
            <div class="counter-box pt-4 pt-md-0">
              <div class="counter-ico">
                <span class="ico-circle"><i class="bi bi-journal-richtext"></i></span>
              </div>
              <div class="counter-num">
                <p data-purecounter-start="0" data-purecounter-end="15" data-purecounter-duration="1" class="counter purecounter"></p>
                <span class="counter-text">YEARS OF EXPERIENCE</span>
              </div>
            </div>
          </div>
          <div class="col-sm-3 col-lg-3">
            <div class="counter-box pt-4 pt-md-0">
              <div class="counter-ico">
                <span class="ico-circle"><i class="bi bi-people"></i></span>
              </div>
              <div class="counter-num">
                <p data-purecounter-start="0" data-purecounter-end="550" data-purecounter-duration="1" class="counter purecounter"></p>
                <span class="counter-text">TOTAL CLIENTS</span>
              </div>
            </div>
          </div>
          <div class="col-sm-3 col-lg-3">
            <div class="counter-box pt-4 pt-md-0" id="bomb">
              <div class="counter-ico">
                <span class="ico-circle"><i class="bi bi-award"></i></span>
              </div>
              <div class="counter-num">
                <p data-purecounter-start="0" data-purecounter-end="6" data-purecounter-duration="1" class="counter purecounter"></p>
                <span class="counter-text">AWARD WON</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    </section><!-- End Counter Section -->
    
    <!-- ======= Blog Section ======= -->
    <section id="blog" class="blog-mf sect-pt4 route">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="title-box text-center">
              <h3 class="title-a">
                Blog
              </h3>
              <p class="subtitle-a">
                We will inform you about all new technology
              </p>
              <div class="line-mf"></div>
            </div>
          </div>
        </div>
        <div class="row">
          <?php $__currentLoopData = $home_blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-4">
            <div class="card card-blog">
              <div class="card-img">
                <a href="<?php echo e(asset('img/'.$list->image)); ?>"><img src="<?php echo e(asset('img/'.$list->image)); ?>" alt="" class="img-fluid"></a>
              </div>
              <div class="card-body">
                <div class="card-category-box">
                  <div class="card-category">
                   <a href="/blog"><h6 class="category"><?php echo e($list->Title); ?></h6></a>
                  </div>
                </div>
                <h3 class="card-title"><a href="/blog">See more ideas about <?php echo e($list->Title); ?></a></h3>
                <p class="card-description justify" style="height:90px;overflow:hidden;">
                <?php echo e($list->description); ?>

                </p>
              </div>
              <div class="card-footer">
                <div class="post-author">
                  <a href="<?php echo e(asset('assets/img/testimonial-2.jpg')); ?>">
                    <!--<img src="assets/img/testimonial-2.jpg" alt="" class="avatar rounded-circle">-->
                    <span class="author"> <a href="/blog" style="color: blue;"> read more</a></span>
                  </a>
                </div>
                <div class="post-date">
                  <span class="bi bi-clock"></span> 30 min
                </div>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </section><!-- End Blog Section -->
    
    <!-- ======= Testimonials Section ======= 
    <section id="testimonials" class="testimonials">
      <div class="container position-relative">

        <div class="testimonials-slider swiper-container" data-aos="fade-up" data-aos-delay="100">
          <div class="swiper-wrapper">

            <div class="swiper-slide">
              <div class="testimonial-item">
                <img src="assets/img/testimonials/testimonials-1.jpg" class="testimonial-img" alt="">
                <h3>Lalit Sharma</h3>
                <h4>Ceo &amp; Founder</h4>
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  I haven't seen such quality work in a long time. i want to say thanks to all vlutech team,..
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
              </div>
            </div><!-- End testimonial item 

            <div class="swiper-slide">
              <div class="testimonial-item">
                <img src="assets/img/testimonials/testimonials-2.jpg" class="testimonial-img" alt="">
                <h3>Ragini</h3>
                <h4>Designer</h4>
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  I haven't seen such quality work in a long time. i want to say thanks to all vlutech team,..
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
              </div>
            </div><!-- End testimonial item

            <div class="swiper-slide">
              <div class="testimonial-item">
                <img src="assets/img/testimonials/testimonials-3.jpg" class="testimonial-img" alt="">
                <h3>Sushmita</h3>
                <h4>Store Owner</h4>
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  I haven't seen such quality work in a long time. i want to say thanks to all vlutech team,..
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
              </div>
            </div><!-- End testimonial item 

            <div class="swiper-slide">
              <div class="testimonial-item">
                <img src="assets/img/testimonials/testimonials-4.jpg" class="testimonial-img" alt="">
                <h3>Rakesh</h3>
                <h4>Freelancer</h4>
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  I haven't seen such quality work in a long time. i want to say thanks to all vlutech team,..
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
              </div>
            </div> End testimonial item 

            <div class="swiper-slide">
              <div class="testimonial-item">
                <img src="assets/img/testimonials/testimonials-5.jpg" class="testimonial-img" alt="">
                <h3>Sunil Grover</h3>
                <h4>Entrepreneur</h4>
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  I haven't seen such quality work in a long time. i want to say thanks to all vlutech team,..
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
              </div>
            </div><!-- End testimonial item 

          </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>
    </section> End Testimonials Section -->
    
    <!-- ======= Contact Section ======= -->
    <section id="contact" class="paralax-mf footer-paralax bg-image sect-mt4 route mfffa" style="background-image: url(assets/img/overlay-bg.jpg)">
      <div class=""></div>
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="contact-mf">
              <div id="contact" class="box-shadow-full">
                <div class="row">
                  <div class="col-md-6">
                    <div class="title-box-2">
                      <h5 class="title-left">
                        Send Message
                      </h5>
                    </div>
                    <div>
                     
                     
                      <form action="" method="post" role="form">
                          <input type="text" name="name" placeholder="name" class="form-control hlwworld" required><br><br>
                          <input type="text" name="email" placeholder="email" class="form-control hlwworld" required><br><br>
                          <input type="text" name="phone" placeholder="phone" class="form-control hlwworld" required><br><br>
                          <textarea name="message" placeholder="message" class="form-control hlwworld" required></textarea><br><br>
                          <input type="submit" name="submit" value="send" class="hlwworld1" style="color:white;font-weight:500;">
                      </form>
                   
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="title-box-2 pt-4 pt-md-0">
                      <h5 class="title-left">
                        Get in Touch
                      </h5>
                    </div>
                    <div class="more-info">
                      <p class="lead leaderss">
                   The vlutech team is looking forward to your call and email, for any inquiry call us directly,
                   we have solution for your Business development.
                    
                      </p>
                      <ul class="list-ico">
                        <li><span class="bi bi-geo-alt" style="font-size:30px;"></span>New Delhi Bawana Sector-1</li>
                        <li><span class="bi bi-phone" style="font-size:30px;"></span>Mr Lalit +91 7701906734</li>
                        <li><span class="bi bi-phone" style="font-size:30px;"></span>Mr Umesh +91 8287178047</li>
                        <li><span class="bi bi-envelope" style="font-size:30px;"></span>info@vlutech.com</li>
                      </ul>
                    </div>
                    <div class="socials">
                      <ul>
                        <li><a href="https://www.facebook.com/"><span class="ico-circle"><i class="bi bi-facebook"></i></span></a></li>
                        <li><a href="https://www.instagram.com/"><span class="ico-circle"><i class="bi bi-instagram"></i></span></a></li>
                        <li><a href="https://www.twitter.com/"><span class="ico-circle"><i class="bi bi-twitter"></i></span></a></li>
                        <li><a href="https://www.linkedin.com/"><span class="ico-circle"><i class="bi bi-linkedin"></i></span></a></li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->


  <!-- ======= Footer ======= -->
  <footer>
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="copyright-box">
            <p class="copyright">&copy; Copyright <strong>Vlutech web solutions</strong></p>
            <div class="credits">
              
             All Rights Reserved units of <a href="https://vlutech.com/">(Vlutech web solutions)</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer><!-- End  Footer -->
  
  <div class="cookie-container">
        <p>Your privacy

By clicking “Accept all cookies”, you agree that we can store cookies on your device and disclose information in accordance with our Cookie Policy.</p>
        <button class="cookie-btn">ok</button>
    </div>

  <!--<div id="preloader"></div> ---->
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<div class="whatsapp">
      <a href="https://wa.me/917701906734" target="blank" class="whatsapp-chat"><img src="<?php echo e(asset('assets/img/whatsapp.png')); ?>" style="width:50px;height:50px; z-index:999;"></a> 
  </div>
  
  
  
  <!-- Template Main JS File -->
  <!-- <script src="assets/js/main.js"></script> -->

  <!-- Vendor JS Files -->
  <!-- <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/typed.js/typed.min.js"></script> -->

  
<script>
    
    const cookieContainer = document.querySelector(".cookie-container");
    const cookieButton =document.querySelector(".cookie-btn");
    
    cookieButton.addEventListener("click",()=>{
        cookieContainer.classList.remove("active");
        localStorage.setItem("cookieBannerDisplayed", "true")
        
    });
    setTimeout( ()=>{
        if(!localStorage.getItem("cookieBannerDisplayed")){
        cookieContainer.classList.add("active");}
    }, 2000);
    
    </script>
 
</body>

</html>





<?php echo $__env->make('front-view.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\vlutech\vlutech\resources\views/front-view/index.blade.php ENDPATH**/ ?>
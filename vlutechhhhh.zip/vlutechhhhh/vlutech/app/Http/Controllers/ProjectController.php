<?php
namespace App\Http\Controllers;

use App\Models\Project;
use Illuminate\Http\Request;

class ProjectController extends Controller
{
    public function index()
    {
        $result['data']=Project::all();
        return view('admin/project',$result);
    }
    
    public function manage_project(Request $request,$id='')
    {
        if($id>0){
            $arr= Project::where(['id'=>$id])->get();
            $result['image']=$arr['0']->image; 
            $result['project_name']=$arr['0']->project_name; 
            $result['design_by']=$arr['0']->design_by;
            
            $result['status']=$arr['0']->status; 
            $result['id']=$arr['0']->id; 
        }
        else{
            $result['image']=''; 
            $result['project_name']=''; 
            $result['design_by']=''; 
            
            $result['status']=''; 
            $result['id']=''; 
        }
        
        return view('admin/manage_project',$result);
    }

    public function manage_project_process(Request $request)
    {
        // return $request->post();
        $request->validate([
            'image'=>'required',
            'project_name'=>'required',
            'design_by'=>'required',
            
        ]);

       
        if($request->post('id')>0)
        {
            $model=Project::find($request->post('id'));
            $msg ="Project Updated";
        }
        else{
            $model=new Project();
            $msg ="Project Inserted";
        }

        if($request->hasfile('image'))
        {
            $file=$request->file('image');
            $extention=$file->getClientOriginalExtension();
            $filename=time().'.'.$extention;
            $file->move('img/', $filename);
            $model->image=$filename;
        }

        
        $model->project_name=$request->post('project_name');
        $model->design_by=$request->post('design_by');
        $model->status=1;
        $model->save();
        $request->session()->flash('message',$msg);
        return redirect('admin/project');
    }

    public function delete(Request $request,$id)
    {
        $model=Project::find($id);
        $model->delete();
        $request->session()->flash('message','Project Deleted');
        return redirect('admin/project');
    }

    public function status(Request $request,$status,$id)
    {
        $model=Project::find($id);
        $model->status=$status;
        $model->save();
        $request->session()->flash('message','Project status updated');
        return redirect('admin/project');
    }
}

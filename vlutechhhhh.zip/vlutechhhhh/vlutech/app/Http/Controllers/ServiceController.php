<?php

namespace App\Http\Controllers;

use App\Models\Service;
use Illuminate\Http\Request;

class ServiceController extends Controller
{
    public function index()
    {
        $result['data']=Service::all();
        return view('admin/service',$result);
    }
    
    public function manage_service(Request $request,$id='')
    {
        if($id>0){
            $arr= Service::where(['id'=>$id])->get();
            
            $result['name']=$arr['0']->name; 
            $result['description']=$arr['0']->description;
            $result['image']=$arr['0']->image; 
            $result['status']=$arr['0']->status; 
            $result['id']=$arr['0']->id; 
        }
        else{
            $result['name']=''; 
            $result['description']=''; 
            $result['image']=''; 
            $result['status']=''; 
            $result['id']=''; 
        }
        
        return view('admin/manage_service',$result);
    }

    public function manage_service_process(Request $request)
    {
        // return $request->post();
        $request->validate([
            'name'=>'required',
            'description'=>'required',
            'image'=>'required',
        ]);

       
        if($request->post('id')>0)
        {
            $model=Service::find($request->post('id'));
            $msg ="Service Updated";
        }
        else{
            $model=new Service();
            $msg ="Service Inserted";
        }
        $model->name=$request->post('name');
        $model->description=$request->post('description');

        if($request->hasfile('image'))
        {
            $file=$request->file('image');
            $extention=$file->getClientOriginalExtension();
            $filename=time().'.'.$extention;
            $file->move('img/', $filename);
            $model->image=$filename;
        }

        $model->status=1;
        $model->save();
        $request->session()->flash('message',$msg);
        return redirect('admin/service');
    }

    public function delete(Request $request,$id)
    {
        $model=Service::find($id);
        $model->delete();
        $request->session()->flash('message','Service Deleted');
        return redirect('admin/service');
    }

    public function status(Request $request,$status,$id)
    {
        $model=Service::find($id);
        $model->status=$status;
        $model->save();
        $request->session()->flash('message','Service status updated');
        return redirect('admin/service');
    }
}

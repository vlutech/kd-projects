<?php

namespace App\Http\Controllers;

use App\Models\Testimonial;
use Illuminate\Http\Request;

class TestimonialController extends Controller
{
    public function index()
    {
        $result['data']=Testimonial::all();
        return view('admin/testimonial',$result);
    }
    
    public function manage_testimonial(Request $request,$id='')
    {
        if($id>0){
            $arr= Testimonial::where(['id'=>$id])->get();
            
            $result['customer_name']=$arr['0']->product_name; 
            $result['image']=$arr['0']->image; 
            $result['description']=$arr['0']->description; 
            $result['status']=$arr['0']->status; 
            $result['id']=$arr['0']->id; 
        }
        else{
            $result['customer_name']=''; 
            $result['image']=''; 
            $result['description']=''; 
            $result['status']=''; 
            $result['id']=''; 
        }
        
        return view('admin/manage_testimonial',$result);
    }

    public function manage_testimonial_process(Request $request)
    {
        // return $request->post();
        $request->validate([
            'customer_name'=>'required',
            'image'=>'required',
            'description'=>'required',
        ]);

       
        if($request->post('id')>0)
        {
            $model=Testimonial::find($request->post('id'));
            $msg ="Testimonial Updated";
        }
        else{
            $model=new Testimonial();
            $msg ="Testimonial Inserted";
        }
        $model->customer_name=$request->post('customer_name');
        if($request->hasfile('image'))
        {
            $file=$request->file('image');
            $extention=$file->getClientOriginalExtension();
            $filename=time().'.'.$extention;
            $file->move('img/', $filename);
            $model->image=$filename;
        }


        $model->description=$request->post('description');
        $model->status=1;
        $model->save();
        $request->session()->flash('message',$msg);
        return redirect('admin/testimonial');
    }

    public function delete(Request $request,$id)
    {
        $model=Testimonial::find($id);
        $model->delete();
        $request->session()->flash('message','Testimonial Deleted');
        return redirect('admin/testimonial');
    }

    public function status(Request $request,$status,$id)
    {
        $model=Testimonial::find($id);
        $model->status=$status;
        $model->save();
        $request->session()->flash('message','Testimonial status updated');
        return redirect('admin/testimonial');
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\Menu;
use Illuminate\Http\Request;

class MenuController extends Controller
{
    public function index()
    {
        $result['data']=Menu::all();
        return view('admin/menu',$result);
    }
    
    public function manage_menu(Request $request,$id='')
    {
        if($id>0){
            $arr= Menu::where(['id'=>$id])->get();
            
            $result['product_name']=$arr['0']->product_name; 
            $result['price']=$arr['0']->price; 
            $result['discount']=$arr['0']->discount; 
            $result['image']=$arr['0']->image;  
            $result['status']=$arr['0']->status; 
            $result['id']=$arr['0']->id; 
        }
        else{
            $result['product_name']=''; 
            $result['price']=''; 
            $result['discount']=''; 
            $result['image']='';  
            $result['status']=''; 
            $result['id']=''; 
        }
        
        return view('admin/manage_menu',$result);
    }

    public function manage_menu_process(Request $request)
    {
        // return $request->post();
        $request->validate([
            'product_name'=>'required',
            'price'=>'required',
            'discount'=>'required',
            'image'=>'required',
        ]);

       
        if($request->post('id')>0)
        {
            $model=Menu::find($request->post('id'));
            $msg ="Menu Updated";
        }
        else{
            $model=new Menu();
            $msg ="Menu Inserted";
        }
        $model->product_name=$request->post('product_name');
        $model->price=$request->post('price');
        $model->discount=$request->post('discount');
        if($request->hasfile('image'))
        {
            $file=$request->file('image');
            $extention=$file->getClientOriginalExtension();
            $filename=time().'.'.$extention;
            $file->move('img/', $filename);
            $model->image=$filename;
        }


        $model->status=1;
        $model->save();
        $request->session()->flash('message',$msg);
        return redirect('admin/menu');
    }

    public function delete(Request $request,$id)
    {
        $model=Menu::find($id);
        $model->delete();
        $request->session()->flash('message','Menu Deleted');
        return redirect('admin/menu');
    }

    public function status(Request $request,$status,$id)
    {
        $model=Menu::find($id);
        $model->status=$status;
        $model->save();
        $request->session()->flash('message','Menu status updated');
        return redirect('admin/menu');
    }
}

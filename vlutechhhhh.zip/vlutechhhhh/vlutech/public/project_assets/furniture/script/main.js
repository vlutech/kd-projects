const openNav = () => {
    document.getElementById('navbar').style.width = "200px";
}
const closeNav = () => {
    document.getElementById('navbar').style.width = "0";
}
<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\ServiceController;
use App\Http\Controllers\ProjectController;
use App\Http\Controllers\MenuController;
use App\Http\Controllers\BannerController;
use App\Http\Controllers\TestimonialController;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\OrderdetailController;
use App\Http\Controllers\FooterController;
use App\Http\Controllers\Front\FrontController;



// Route::get('/',[FrontController::class,'index']);
// Route::get('/blog',[FrontController::class,'blog']);

// Route::view('/blog', function () {
//     return view('front_view/blog');
// });

 

Route::get('/', function () {
    return view('front-view.index');
});
Route::get('/',[FrontController::class,'index']);
Route::view('/blog','blog');
Route::get('/blog',[FrontController::class,'blog']);
Route::view('/car','projects.car.index');
Route::view('/e-commerce','projects.e-commerce.index');
Route::view('/furniture','projects.furniture.index');
Route::view('/grocery','projects.grocery.index');
Route::view('/gym','projects.gym.index');
Route::view('/jewellery','projects.jewellery.index');
Route::view('/phone','projects.phone.index');
Route::view('/real-estate','projects.real-estate.index');







Route::get('admin',[AdminController::class,'index']);
Route::post('admin/auth',[AdminController::class,'auth'])->name('admin.auth');

Route::group(['middleware'=>'admin_auth'],function(){
    Route::get('admin/dashboard',[AdminController::class,'dashboard']);

//Service page routs starts here
    Route::get('admin/service',[ServiceController::class,'index']);
    Route::get('admin/service/manage_service',[ServiceController::class,'manage_service']);
    Route::get('admin/service/manage_service/{id}',[ServiceController::class,'manage_service']);
    Route::post('admin/service/manage_service_process',[ServiceController::class,'manage_service_process'])->name('service.manage_service_process');
    Route::get('admin/service/delete/{id}',[ServiceController::class,'delete']);
    Route::get('admin/service/status/{status}/{id}',[ServiceController::class,'status']);
//Service page routs end here

//project page routs starts here
    Route::get('admin/project',[ProjectController::class,'index']);
    Route::get('admin/project/manage_project',[ProjectController::class,'manage_project']);
    Route::get('admin/project/manage_project/{id}',[ProjectController::class,'manage_project']);
    Route::post('admin/project/manage_project_process',[ProjectController::class,'manage_project_process'])->name('project.manage_project_process');
    Route::get('admin/project/delete/{id}',[ProjectController::class,'delete']);
    Route::get('admin/project/status/{status}/{id}',[ProjectController::class,'status']);
//project page routs end here

//Banner page routs starts here
Route::get('admin/banner',[BannerController::class,'index']);
Route::get('admin/banner/manage_banner',[BannerController::class,'manage_banner']);
Route::get('admin/banner/manage_banner/{id}',[BannerController::class,'manage_banner']);
Route::post('admin/banner/manage_banner_process',[BannerController::class,'manage_banner_process'])->name('banner.manage_banner_process');
Route::get('admin/banner/delete/{id}',[BannerController::class,'delete']);
Route::get('admin/banner/status/{status}/{id}',[BannerController::class,'status']);
//Banner page routs end here

//blog page routs starts here
    Route::get('admin/blog',[BlogController::class,'index']);
    Route::get('admin/blog/manage_blog',[BlogController::class,'manage_blog']);
    Route::get('admin/blog/manage_blog/{id}',[BlogController::class,'manage_blog']);
    Route::post('admin/blog/manage_blog_process',[BlogController::class,'manage_blog_process'])->name('blog.manage_blog_process');
    Route::get('admin/blog/delete/{id}',[BlogController::class,'delete']);
    Route::get('admin/blog/status/{status}/{id}',[BlogController::class,'status']);
//blog page routs end here


//Product page routs starts here
Route::get('admin/product/product',[ProductController::class,'index']);
Route::get('admin/product/product/manage_product',[ProductController::class,'manage_product']);
Route::get('admin/product/product/manage_product/{id}',[ProductController::class,'manage_product']);
Route::post('admin/product/product/manage_product_process',[ProductController::class,'manage_product_process'])->name('product.product.manage_product_process');
Route::get('admin/product/product/delete/{id}',[ProductController::class,'delete']);
Route::get('admin/product/product/status/{status}/{id}',[ProductController::class,'status']);
//Product page routs end here

//Menu page routs starts here
Route::get('admin/menu',[MenuController::class,'index']);
Route::get('admin/menu/manage_menu',[MenuController::class,'manage_menu']);
Route::get('admin/menu/manage_menu/{id}',[MenuController::class,'manage_menu']);
Route::post('admin/menu/manage_menu_process',[MenuController::class,'manage_menu_process'])->name('menu.manage_menu_process');
Route::get('admin/menu/delete/{id}',[MenuController::class,'delete']);
Route::get('admin/menu/status/{status}/{id}',[MenuController::class,'status']);
//Menu page routs end here

//Testimonial page routs starts here
Route::get('admin/testimonial',[TestimonialController::class,'index']);
Route::get('admin/testimonial/manage_testimonial',[TestimonialController::class,'manage_testimonial']);
Route::get('admin/testimonial/manage_testimonial/{id}',[TestimonialController::class,'manage_testimonial']);
Route::post('admin/testimonial/manage_testimonial_process',[TestimonialController::class,'manage_testimonial_process'])->name('testimonial.manage_testimonial_process');
Route::get('admin/testimonial/delete/{id}',[TestimonialController::class,'delete']);
Route::get('admin/testimonial/status/{status}/{id}',[TestimonialController::class,'status']);
//Testimonial page routs end here

//Order-details page routs starts here
Route::get('admin/orderdetail',[OrderdetailController::class,'index']);
Route::get('admin/orderdetail/manage_orderdetail',[OrderdetailController::class,'manage_orderdetail']);
Route::get('admin/orderdetail/manage_orderdetail/{id}',[OrderdetailController::class,'manage_orderdetail']);
Route::post('admin/orderdetail/manage_orderdetail_process',[OrderdetailController::class,'manage_orderdetail_process'])->name('orderdetail.manage_orderdetail_process');
Route::get('admin/orderdetail/delete/{id}',[OrderdetailController::class,'delete']);
Route::get('admin/orderdetail/status/{status}/{id}',[OrderdetailController::class,'status']);
//Order-details page routs end here

//Footer page routs starts here
Route::get('admin/footer',[FooterController::class,'index']);
Route::get('admin/footer/manage_footer',[FooterController::class,'manage_footer']);
Route::get('admin/footer/manage_footer/{id}',[FooterController::class,'manage_footer']);
Route::post('admin/footer/manage_footer_process',[FooterController::class,'manage_footer_process'])->name('footer.manage_footer_process');
Route::get('admin/footer/delete/{id}',[FooterController::class,'delete']);
Route::get('admin/footer/status/{status}/{id}',[FooterController::class,'status']);
//Footer page routs end here


//Custumer review page routs starts here
// Route::get('/admin/customerreview',[CustomerreviewController::class,'index']);
Route::get('admin/customerreview', function () {
    return view('admin/customerreview');
});
//Custumer review page routs end here


    Route::get('admin/logout', function () {
        session()->forget('ADMIN_LOGIN');
        session()->forget('ADMIN_ID');
        session()->flash('error','Logout Successfully');
        return redirect('admin');
    });
});


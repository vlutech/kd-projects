<?php

namespace App\Http\Controllers;

use App\Models\Women;
use Illuminate\Http\Request;

class WomenController extends Controller
{
    public function index()
    {
        $result['data']=Women::all();
        return view('admin/product/banner/women',$result);
    }
    
    public function manage_women(Request $request,$id='')
    {
        if($id>0){
            $arr= Women::where(['id'=>$id])->get();
            
            $result['product_name']=$arr['0']->product_name; 
            $result['price']=$arr['0']->price; 
            $result['discount']=$arr['0']->discount; 
            $result['image']=$arr['0']->image; 
            $result['description']=$arr['0']->description; 
            $result['status']=$arr['0']->status; 
            $result['id']=$arr['0']->id; 
        }
        else{
            $result['product_name']=''; 
            $result['price']=''; 
            $result['discount']=''; 
            $result['image']=''; 
            $result['description']=''; 
            $result['status']=''; 
            $result['id']=''; 
        }
        
        return view('admin/product/banner/manage_women',$result);
    }

    public function manage_women_process(Request $request)
    {
        // return $request->post();
        $request->validate([
            'product_name'=>'required',
            'price'=>'required',
            'discount'=>'required',
            'image'=>'required',
            'description'=>'required',
        ]);

       
        if($request->post('id')>0)
        {
            $model=Women::find($request->post('id'));
            $msg ="Women Updated";
        }
        else{
            $model=new Women();
            $msg ="Women Inserted";
        }
        $model->product_name=$request->post('product_name');
        $model->price=$request->post('price');
        $model->discount=$request->post('discount');
        
        if($request->hasfile('image'))
        {
            $file=$request->file('image');
            $extention=$file->getClientOriginalExtension();
            $filename=time().'.'.$extention;
            $file->move('img/', $filename);
            $model->image=$filename;
        }


        $model->description=$request->post('description');
        $model->status=1;
        $model->save();
        $request->session()->flash('message',$msg);
        return redirect('admin/product/banner/women');
    }

    public function delete(Request $request,$id)
    {
        $model=Women::find($id);
        $model->delete();
        $request->session()->flash('message','Women Deleted');
        return redirect('admin/product/banner/women');
    }

    public function status(Request $request,$status,$id)
    {
        $model=Women::find($id);
        $model->status=$status;
        $model->save();
        $request->session()->flash('message','Women status updated');
        return redirect('admin/product/banner/women');
    }
}

<?php

namespace App\Http\Controllers\Front;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
// use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;

class FrontController extends Controller
{
    public function index(Request $request)
    {

        $result['home_banners']=DB::table('banners')
        ->where(['status'=>1])
        ->get();

        // $result['home_categories']=DB::table('categories')
        // ->where(['status'=>1])
        // ->get();

        // $result['home_testimonials']=DB::table('testimonials')
        // ->where(['status'=>1])
        
        // ->get();

        $result['home_blogs']=DB::table('blogs')
        ->where(['status'=>1])
        
        ->get();

        $result['home_products']=DB::table('products')
        ->where(['status'=>1])
        
        ->get();

        $result['home_testimonials']=DB::table('testimonials')
        ->where(['status'=>1])
        
        ->get();

        $result['home_banners']=DB::table('banners')
        ->where(['status'=>1])
        
        ->get();

        $result['home_menus']=DB::table('menus')
        ->where(['status'=>1])
        
        ->get();
        // $result['home_brands']=DB::table('brands')
        // ->where(['status'=>1])
        
        // ->get();

        
        return view('front_view.index',$result);
    }

    public function blog(Request $request)
    {
        $result['home_blogs']=DB::table('blogs')
        ->where(['status'=>1])
        
        ->get();
        return view('front_view.blog',$result);
    }

    
}

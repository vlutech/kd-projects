-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 17, 2021 at 05:38 PM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `coffee`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
CREATE TABLE IF NOT EXISTS `admins` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `email`, `password`, `created_at`, `updated_at`) VALUES
(1, 'kd8919@gmail.com', '$2y$10$e4tSQc1lqcWhknmLkRd6I.RXLDeT9ebDr2K0GfKos4cqj04OHlq/i', '2021-09-19 00:46:20', '2021-09-20 01:49:03');

-- --------------------------------------------------------

--
-- Table structure for table `banners`
--

DROP TABLE IF EXISTS `banners`;
CREATE TABLE IF NOT EXISTS `banners` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `discount` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `banners`
--

INSERT INTO `banners` (`id`, `product_name`, `price`, `discount`, `image`, `description`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Office Bag', 111, '11%', '1634309642.jpeg', 'bag', '1', '2021-09-24 18:30:00', '2021-10-15 09:24:02');

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

DROP TABLE IF EXISTS `blogs`;
CREATE TABLE IF NOT EXISTS `blogs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` (`id`, `Title`, `image`, `description`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Devlopers', '1634211007.png', 'Laravel', '1', '2021-09-29 09:31:00', '2021-10-14 06:02:26'),
(2, 'new digital marketing', '1634211173.png', 'Laravel is a free, open-source PHP', '1', '2021-10-03 03:23:48', '2021-10-15 10:07:48'),
(3, 'coffee', '1634211030.png', 'dddddddddddd', '1', '2021-10-14 06:00:30', '2021-10-14 06:00:30');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

DROP TABLE IF EXISTS `brands`;
CREATE TABLE IF NOT EXISTS `brands` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `product_name`, `image`, `description`, `status`, `created_at`, `updated_at`) VALUES
(1, 'zzz2', '1633251311.png', 'adsagf', '1', '2021-09-29 02:49:54', '2021-10-03 04:16:32'),
(2, 'css-3', '1633252591.png', 'for styling', '1', '2021-10-03 03:46:31', '2021-10-03 03:46:31'),
(3, 'Java', '1633252617.png', 'java', '1', '2021-10-03 03:46:57', '2021-10-03 03:46:57'),
(4, 'joomla', '1633252636.png', 'joomla', '1', '2021-10-03 03:47:16', '2021-10-03 03:47:16'),
(5, 'wordpress', '1633252947.png', 'wordpress', '1', '2021-10-03 03:52:27', '2021-10-03 04:16:28'),
(6, 'j-query', '1633253025.png', 'j-query', '1', '2021-10-03 03:53:45', '2021-10-03 03:53:45');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `status` int(11) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_name`, `category_slug`, `image`, `created_at`, `status`, `updated_at`) VALUES
(2, 'lalit', 'gym', '1633241726.jpg', '2021-09-20 03:34:11', 1, '2021-10-03 00:45:26'),
(4, 'kidssskkkkkkkkkr', 'kid', '1633241740.jpg', '2021-09-20 05:07:24', 1, '2021-10-03 00:45:40'),
(13, 'sports', 'sports', '1633241758.jpg', '2021-09-21 05:15:51', 1, '2021-10-03 00:45:58'),
(12, 'frst', 'frst', '1633241775.jpg', '2021-09-20 05:45:13', 1, '2021-10-03 00:46:15'),
(18, 'cook', 'cook', '', '2021-10-02 05:47:24', 0, '2021-10-03 02:05:35');

-- --------------------------------------------------------

--
-- Table structure for table `colors`
--

DROP TABLE IF EXISTS `colors`;
CREATE TABLE IF NOT EXISTS `colors` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `colors`
--

INSERT INTO `colors` (`id`, `color`, `status`, `created_at`, `updated_at`) VALUES
(1, 'saffron', 1, '2021-09-24 03:20:52', '2021-09-26 05:49:50'),
(2, 'cyan', 1, '2021-09-24 03:21:05', '2021-09-26 06:00:23');

-- --------------------------------------------------------

--
-- Table structure for table `coupons`
--

DROP TABLE IF EXISTS `coupons`;
CREATE TABLE IF NOT EXISTS `coupons` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `coupons`
--

INSERT INTO `coupons` (`id`, `title`, `code`, `value`, `status`, `created_at`, `updated_at`) VALUES
(2, 'Coupon-112', '#214673123', '11112', 0, '2021-09-21 06:17:39', '2021-09-26 05:25:45'),
(4, 'ffff', 'fff', '55', 1, '2021-09-24 08:53:01', '2021-10-14 04:08:11'),
(5, 'red', 'red', '1', 1, '2021-09-24 08:55:15', '2021-09-24 08:55:30');

-- --------------------------------------------------------

--
-- Table structure for table `electronics`
--

DROP TABLE IF EXISTS `electronics`;
CREATE TABLE IF NOT EXISTS `electronics` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `discount` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `electronics`
--

INSERT INTO `electronics` (`id`, `product_name`, `price`, `discount`, `image`, `description`, `status`, `created_at`, `updated_at`) VALUES
(1, 'hjkhb1', 343331, '3241', '1633241818.png', 'rtdtr1', '1', '2021-09-29 01:54:54', '2021-10-03 00:47:30');

-- --------------------------------------------------------

--
-- Table structure for table `featureds`
--

DROP TABLE IF EXISTS `featureds`;
CREATE TABLE IF NOT EXISTS `featureds` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `discount` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `featureds`
--

INSERT INTO `featureds` (`id`, `product_name`, `price`, `discount`, `image`, `description`, `status`, `created_at`, `updated_at`) VALUES
(1, 'f', 44, '4', '1633246152.png', 'r', '1', '2021-09-29 09:16:46', '2021-10-03 01:59:12'),
(2, 'hhhh', 653465, '45', '1633246313.png', 'gdf', '1', '2021-10-03 02:01:53', '2021-10-03 02:01:53');

-- --------------------------------------------------------

--
-- Table structure for table `footers`
--

DROP TABLE IF EXISTS `footers`;
CREATE TABLE IF NOT EXISTS `footers` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `menu` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `discount` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `offer` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `site_map` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `suppliers` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `faq` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `links` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `footers`
--

INSERT INTO `footers` (`id`, `menu`, `discount`, `offer`, `site_map`, `suppliers`, `faq`, `address`, `mobile`, `email`, `links`, `status`, `created_at`, `updated_at`) VALUES
(1, 'home', '55', '55', '555', '55', '55', '55', '8394885888', 'kd8919gmail.com', 'www.vlutech.com', 1, '2021-09-29 08:41:15', '2021-10-03 02:52:14');

-- --------------------------------------------------------

--
-- Table structure for table `latests`
--

DROP TABLE IF EXISTS `latests`;
CREATE TABLE IF NOT EXISTS `latests` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `discount` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `latests`
--

INSERT INTO `latests` (`id`, `product_name`, `price`, `discount`, `image`, `description`, `status`, `created_at`, `updated_at`) VALUES
(1, 'lll', 666, '5', '1633246397.png', 'gggg', '1', '2021-09-29 09:18:26', '2021-10-03 02:03:17');

-- --------------------------------------------------------

--
-- Table structure for table `mens`
--

DROP TABLE IF EXISTS `mens`;
CREATE TABLE IF NOT EXISTS `mens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` int(11) NOT NULL,
  `username` int(11) NOT NULL,
  `image` int(11) NOT NULL,
  `description` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

DROP TABLE IF EXISTS `menus`;
CREATE TABLE IF NOT EXISTS `menus` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `discount` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(255) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `product_name`, `price`, `discount`, `image`, `status`, `created_at`, `updated_at`) VALUES
(1, 'coffee', '39', '5', '1634308836.jpeg', 1, NULL, '2021-10-15 09:10:59'),
(2, 'coffee2', '25', '10', '1634308818.jpeg', 1, '2021-10-15 09:10:18', '2021-10-15 09:10:18');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_admins_table', 1),
(2, '2021_09_19_104920_create_categories_table', 2),
(3, '2021_09_21_065326_create_coupons_table', 3),
(4, '2021_09_22_092617_create_posts_table', 4),
(5, '2021_09_22_091627_create_sizes_table', 5),
(6, '2021_09_24_080333_create_colors_table', 6),
(7, '2021_09_24_110135_create_products_table', 7),
(8, '2021_09_24_112239_create_products_table', 8),
(9, '2021_09_25_090711_create_productitem_table', 9),
(10, '2021_09_25_115800_create_banner_table', 10),
(11, '2021_09_25_120224_create_banner_table', 11),
(12, '2021_09_27_095131_create_topproducts_table', 12),
(13, '2021_09_27_110238_create_mens_table', 13),
(14, '2021_09_27_111659_create_womens_table', 14),
(15, '2021_09_27_113034_create_sports_table', 15),
(16, '2021_09_28_052619_create_orderdetails_table', 16),
(17, '2021_09_29_070948_create_electronics_table', 17),
(18, '2021_09_29_081011_create_bannerforsales_table', 18),
(19, '2021_09_29_082104_create_populars_table', 19),
(20, '2021_09_29_082301_create_featureds_table', 20),
(21, '2021_09_29_082436_create_latests_table', 21),
(22, '2021_09_29_082618_create_testimonials_table', 22),
(23, '2021_09_29_082913_create_blogs_table', 23),
(24, '2021_09_29_132503_create_footers_table', 24),
(25, '2021_10_15_075113_create_menus_table', 25);

-- --------------------------------------------------------

--
-- Table structure for table `orderdetails`
--

DROP TABLE IF EXISTS `orderdetails`;
CREATE TABLE IF NOT EXISTS `orderdetails` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Customer_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Mobile` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orderdetails`
--

INSERT INTO `orderdetails` (`id`, `Customer_name`, `Address`, `Mobile`, `product_name`, `price`, `image`, `payment_method`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Kapil Dev', 'c-1392', '8394885888', 'Lenovo Laptop', '500$', '1632821638.jpg', 'Debit Card', '1', '2021-09-27 18:30:00', '2021-09-28 04:03:58'),
(2, 'jjj', 'jjj', '9889898998', 'kkk', '656565', '1632821178.jpeg', 'Cash On Delivery', '1', '2021-09-28 01:12:37', '2021-09-28 03:56:18'),
(3, 'ddd', 'ddd', '555', 'dddd', '555', '1632819174.jpg', 'UPI', '1', '2021-09-28 01:33:37', '2021-09-28 03:22:54'),
(4, 'wwww', 'www', '333333', 'wwwww', '333', '1632820223.jpg', 'Credit Card', '1', '2021-09-28 02:55:50', '2021-09-28 03:40:23'),
(5, 'harish', 'ff', 'ff', 'ff', 'ff', '1632821612.jpg', 'Debit Card', '1', '2021-09-28 03:00:58', '2021-09-28 04:03:32');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `populars`
--

DROP TABLE IF EXISTS `populars`;
CREATE TABLE IF NOT EXISTS `populars` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `discount` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `populars`
--

INSERT INTO `populars` (`id`, `product_name`, `price`, `discount`, `image`, `description`, `status`, `created_at`, `updated_at`) VALUES
(1, 'tea', 331, '3', '1633243695.png', 'dsf', '1', '2021-09-29 09:08:09', '2021-10-03 01:18:15'),
(2, 'ss', 22, '2', '1633243711.png', 'xxx', '1', '2021-09-29 09:14:37', '2021-10-03 01:18:31'),
(3, 'ff', 333, '33', '1633243763.png', 'dfds', '1', '2021-10-03 01:19:23', '2021-10-03 01:19:23'),
(4, 'fdg', 454, '3', '1633243780.png', 'dfd', '1', '2021-10-03 01:19:40', '2021-10-03 01:19:40'),
(5, 'gfg', 33333, '5', '1633243810.png', 'fdsg', '1', '2021-10-03 01:20:10', '2021-10-03 01:20:10');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `discount` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_name`, `price`, `discount`, `image`, `description`, `status`, `created_at`, `updated_at`) VALUES
(1, 'polo t-shirt', 232, '43', '1634308899.png', 'new look', '1', '2021-09-27 05:44:51', '2021-10-15 09:11:39'),
(4, 't-shirt', 333, '11%', '1634308935.png', 'with round neck', '0', '2021-10-01 06:45:30', '2021-10-15 09:17:50'),
(3, 'polo T-shirt', 399, '10%', '1634308989.png', 'new design', '1', '2021-10-01 06:29:16', '2021-10-15 09:13:09'),
(5, 't-shirts', 199, '11%', '1634309025.png', 'v shape', '1', '2021-10-01 06:46:02', '2021-10-15 09:13:45'),
(6, 't shirts', 111, '11%', '1634309009.png', 'black', '0', '2021-10-01 06:46:29', '2021-10-15 09:16:33'),
(7, 'shirt', 999, '10%', '1634309085.png', 'trending', '1', '2021-10-01 06:47:00', '2021-10-15 09:14:45'),
(8, 'polo t-shirts', 222, '23%', '1634309103.png', 'new', '1', '2021-10-01 06:47:59', '2021-10-15 09:15:03'),
(9, 'shirt', 111, '5%', '1634309122.png', 'new design', '1', '2021-10-01 06:48:29', '2021-10-15 09:15:22'),
(10, 'vlutech belt', 1500, '67', '1634309241.png', 'that a leather belt in discounting price', '1', '2021-10-03 04:28:07', '2021-10-15 09:17:21'),
(11, 'coffee', 199, '10%', '1634207391.png', 'aaaaaa', '1', '2021-10-14 04:59:51', '2021-10-14 04:59:51');

-- --------------------------------------------------------

--
-- Table structure for table `sizes`
--

DROP TABLE IF EXISTS `sizes`;
CREATE TABLE IF NOT EXISTS `sizes` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sizes`
--

INSERT INTO `sizes` (`id`, `size`, `status`, `created_at`, `updated_at`) VALUES
(1, 'xl', 1, '2021-09-22 04:51:31', '2021-09-26 06:00:16');

-- --------------------------------------------------------

--
-- Table structure for table `sports`
--

DROP TABLE IF EXISTS `sports`;
CREATE TABLE IF NOT EXISTS `sports` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `discount` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sports`
--

INSERT INTO `sports` (`id`, `product_name`, `price`, `discount`, `image`, `description`, `status`, `created_at`, `updated_at`) VALUES
(1, 'ndmfs', 34, '234', '1633176747.png', 'fdg', '1', '2021-09-27 06:12:03', '2021-10-02 06:42:27'),
(2, 'fgg', 455, '4', '1633245363.png', 'f', '1', '2021-10-03 01:46:03', '2021-10-03 01:46:03'),
(3, 'rt', 4, '4', '1633245379.png', 'er', '1', '2021-10-03 01:46:19', '2021-10-03 01:46:19');

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

DROP TABLE IF EXISTS `testimonials`;
CREATE TABLE IF NOT EXISTS `testimonials` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `testimonials`
--

INSERT INTO `testimonials` (`id`, `customer_name`, `image`, `description`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Mr Dev', '1634213860.png', 'hlw world this is a test msg from dev', '1', '2021-09-29 09:35:22', '2021-10-14 06:47:40'),
(2, 'Ms pooja', '1634213880.png', 'Vlutech Web Solutions Private Limited is a premium design company that focuses on quality, innovat', '1', '2021-10-03 02:18:49', '2021-10-14 06:48:00');

-- --------------------------------------------------------

--
-- Table structure for table `topproducts`
--

DROP TABLE IF EXISTS `topproducts`;
CREATE TABLE IF NOT EXISTS `topproducts` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `discount` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `topproducts`
--

INSERT INTO `topproducts` (`id`, `product_name`, `price`, `discount`, `image`, `description`, `status`, `created_at`, `updated_at`) VALUES
(1, 'hlw from top', 999, '50%', 'img/FwEohCaGeIdBPwwwI9Uk7xWG9vz5u7JoldCkGJOA.jpg', 'latest model', '1', '2021-09-27 05:28:50', '2021-09-27 05:28:50'),
(2, 'Kapil Dev', 10000, '0%', 'img/o1qig3lyCPeqIsVoO4HEuV6feBhpeu2nX5ZiiNEI.jpg', 'Devloper', '1', '2021-09-27 05:43:11', '2021-09-27 05:43:11');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `womens`
--

DROP TABLE IF EXISTS `womens`;
CREATE TABLE IF NOT EXISTS `womens` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `discount` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `womens`
--

INSERT INTO `womens` (`id`, `product_name`, `price`, `discount`, `image`, `description`, `status`, `created_at`, `updated_at`) VALUES
(1, 'hiii', 111, '11', '1633176041.png', 'women', '1', '2021-09-27 05:57:40', '2021-10-02 06:30:41'),
(2, 'sport', 111, '111', '1633176052.png', 'dsdd', '1', '2021-09-27 06:09:55', '2021-10-02 06:30:52'),
(3, 'hhh', 78, '7', '1633240156.png', 'ssss', '1', '2021-10-03 00:18:35', '2021-10-03 00:19:16');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php $__env->startSection('container'); ?>

<section class="home" id="home">
<?php $__currentLoopData = $home_banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div style="width: 100%;">
<img src="<?php echo e(asset('img/'.$list->image)); ?>" alt="" style="float:left;width:100%;z-index: 888;">
</div>
    <div class="content" style="z-index: 999; float:left;position:absolute;left:150px;top:40%;">
        <h3><?php echo e($list->product_name); ?></h3><img src="" alt="" />
        <p><?php echo e($list->description); ?></p>
        <a href="#" class="btn">get yours now</a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>

<!-- home section ends -->

<!-- about section starts  -->

<section class="about" id="about">

    <h1 class="heading"> <span>about</span> us </h1>

    <div class="row">

        <div class="image">
            <img src="<?php echo e(asset('images/about-img.jpeg')); ?>" alt="">
        </div>

        <div class="content">
            <h3>what makes our coffee special?</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus qui ea ullam, enim tempora ipsum fuga alias quae ratione a officiis id temporibus autem? Quod nemo facilis cupiditate. Ex, vel?</p>
            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Odit amet enim quod veritatis, nihil voluptas culpa! Neque consectetur obcaecati sapiente?</p>
            <a href="#" class="btn">learn more</a>
        </div>

    </div>

</section>

<!-- about section ends -->

<!-- menu section starts  -->

<section class="menu" id="menu">

    <h1 class="heading"> our <span>menu</span> </h1>

    <div class="box-container">
<?php $__currentLoopData = $home_menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="box">
            <img src="<?php echo e(asset('img/'.$list->image)); ?>" alt="">
            <h3><?php echo e($list->product_name); ?></h3>
            <div class="price">$<?php echo e($list->price); ?> <span><?php echo e($list->discount); ?></span></div>
            <a href="#" class="btn">add to cart</a>
        </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </div>

</section>

<!-- menu section ends -->

<section class="products" id="products">

    <h1 class="heading"> our <span>products</span> </h1>

    <div class="box-container">
<?php $__currentLoopData = $home_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="box">
            <div class="icons">
                <a href="#" class="fas fa-shopping-cart"></a>
                <a href="#" class="fas fa-heart"></a>
                <a href="#" class="fas fa-eye"></a>
            </div>
            <div class="image">
                <img src="<?php echo e(asset('img/'.$list->image)); ?>" alt="">
            </div>
            <div class="content">
                <h3><?php echo e($list->product_name); ?></h3>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <div class="price"><?php echo e($list->price); ?> <span><?php echo e($list->discount); ?></span></div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
    </div>

</section>

<!-- review section starts  -->

<section class="review" id="review">

    <h1 class="heading">Testimo<span>nials</span> </h1>

    <div class="box-container">
<?php $__currentLoopData = $home_testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="box">
            <!-- <img src="<?php echo e(asset('img/'.$list->image)); ?>" alt="<?php echo e(asset('img/'.$list->image)); ?>" class="quote"> -->
            <p><?php echo e($list->description); ?></p>
            <img src="<?php echo e(asset('img/'.$list->image)); ?>" class="user" alt="">
            <h3><?php echo e($list->customer_name); ?></h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
        </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </div>

</section>

<!-- review section ends -->

<!-- contact section starts  -->

<section class="contact" id="contact">

    <h1 class="heading"> <span>contact</span> us </h1>

    <div class="row">

        <iframe class="map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d30153.788252261566!2d72.82321484621745!3d19.141690214227783!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7b63aceef0c69%3A0x2aa80cf2287dfa3b!2sJogeshwari%20West%2C%20Mumbai%2C%20Maharashtra%20400047!5e0!3m2!1sen!2sin!4v1629452077891!5m2!1sen!2sin" allowfullscreen="" loading="lazy"></iframe>

        <form action="">
            <h3>get in touch</h3>
            <div class="inputBox">
                <span class="fas fa-user"></span>
                <input type="text" placeholder="name">
            </div>
            <div class="inputBox">
                <span class="fas fa-envelope"></span>
                <input type="email" placeholder="email">
            </div>
            <div class="inputBox">
                <span class="fas fa-phone"></span>
                <input type="number" placeholder="number">
            </div>
            <input type="submit" value="contact now" class="btn">
        </form>

    </div>

</section>

<!-- contact section ends -->

<!-- blogs section starts  -->

<section class="blogs" id="blogs">

    <h1 class="heading"> our <span>blogs</span> </h1>

    <div class="box-container">
    <?php $__currentLoopData = $home_blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="box">
            <div class="image">
                <img src="<?php echo e(asset('img/'.$list->image)); ?>" alt="">
            </div>
            <div class="content">
                <a href="#" class="title"><?php echo e($list->Title); ?></a>
                <span>by admin / <?php echo e($list->created_at); ?></span>
                <p><?php echo e($list->description); ?></p>
                <a href="<?php echo e(asset('/blog')); ?>/<?php echo e($list->id); ?>" class="btn">read more</a>
            </div>
        </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       

    </div>

</section>
<?php $__env->stopSection(); ?>


<!-- custom js file link  -->
<script src="<?php echo e(asset('js/script.js')); ?>"></script>

</body>
</html>
<?php echo $__env->make('front_view/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Coffee\resources\views/front_view/index.blade.php ENDPATH**/ ?>


<section class="blogs" id="blogs">

    <h1 class="heading"> our <span>blogs</span> </h1>

    <div class="box-container">
<?php $__currentLoopData = $home_blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="box">
            <div class="image">
                <img src="<?php echo e(asset('img/'.$list->image)); ?>" alt="">
            </div>
            <div class="content">
                <a href="#" class="title"><?php echo e($list->Title); ?></a>
                <span>by admin / <?php echo e($list->created_at); ?></span>
                <p><?php echo e($list->description); ?></p>
                <a href="#" class="btn">read more</a>
            </div>
        </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       

    </div>

</section>
<?php echo $__env->make('front_view/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Coffee\resources\views/front_view/blog.blade.php ENDPATH**/ ?>
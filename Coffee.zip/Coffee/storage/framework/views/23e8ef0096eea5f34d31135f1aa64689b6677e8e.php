
<?php $__env->startSection('page_title','Coupon'); ?>
<?php $__env->startSection('container'); ?>
<?php $__env->startSection('coupon_select','active'); ?>


<h1 class="mb10">Coupon</h1>
<a href="<?php echo e(url('admin/coupon/manage_coupon')); ?>">
    <button type="button" class="btn btn-success"> Add Coupon</button>
</a>
<div class="row m-t-30">
        <div class="col-md-12 col-sm-12">
            <!-- DATA TABLE-->
            <div class="table-responsive m-b-40">
                <table class="table table-borderless table-data3">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Code</th>
                            <th>Value</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($list->id); ?></td>
                            <td><?php echo e($list->title); ?></td>
                            <td><?php echo e($list->code); ?></td>
                            <td><?php echo e($list->value); ?></td>
                            <td>
                                <a href="<?php echo e(url('admin/coupon/delete/')); ?>/<?php echo e($list->id); ?>">
                                    <button type="button" class="btn btn-danger">Delete</button>
                                </a>
                                <?php if($list->status==1): ?>
                                <a href="<?php echo e(url('admin/coupon/status/0')); ?>/<?php echo e($list->id); ?>">
                                    <button type="button" class="btn btn-success">
                                        <i class="fa fa-check" aria-hidden="true"></i>
                                    </button>
                                </a>
                                <?php elseif($list->status==0): ?>
                                <a href="<?php echo e(url('admin/coupon/status/1')); ?>/<?php echo e($list->id); ?>">
                                    <button type="button" class="btn btn-warning">
                                        <i class="fa fa-times" aria-hidden="true"></i>
                                    </button>
                                </a>
                                <?php endif; ?>
                                <a href="<?php echo e(url('admin/coupon/manage_coupon/')); ?>/<?php echo e($list->id); ?>">
                                    <button type="button" class="btn btn-success">Edit</button>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </tbody>
                </table>
            </div>
            <!-- END DATA TABLE-->
        </div>
    </div>


    <?php if(session()->has('message')): ?>
<script>
       
iziToast.info({
    timeout: 5000,
    overlay: false,
    displayMode: 'once',
    id: 'inputs',
    zindex: 1,
    title: "<h3 class='text-danger'>Alert-:</h3>",
    message: "<h3 class='text-success'><?php echo e(session('message')); ?></h3>",
    position: 'center',
    drag: true,
    
});
       
    </script>
    <?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Coffee\resources\views/admin/coupon.blade.php ENDPATH**/ ?>
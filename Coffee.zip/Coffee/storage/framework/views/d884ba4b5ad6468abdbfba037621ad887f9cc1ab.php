
<?php $__env->startSection('page_title','Banner'); ?>
<?php $__env->startSection('product_select','active'); ?>
<?php $__env->startSection('container'); ?>



<div>
<h1 class="" align=center>Product</h1>
<h5><?php echo e(session('name')); ?></h5>
<a href="<?php echo e(url('admin/product/banner/banner/manage_banner')); ?>">
    <button type="button" class="btn btn-success"> Add Product</button>
</a>
<div class="row m-t-30">
        <div class="col-md-12 col-sm-12">
            <!-- DATA TABLE-->
            <div class="table-responsive m-b-40">
                <table class="table table-borderless table-data3">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Product Name</th>
                            <th>Price</th>
                            <th>Discount</th>
                            <th>Image</th>
                            <th>Description</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($list->id); ?></td>
                            <td><?php echo e($list->product_name); ?></a>
                            <td><?php echo e($list->price); ?></td>
                            <td><?php echo e($list->discount); ?></td>
                            <td><a href="<?php echo e(asset('/img/'.$list->image)); ?>"><img src="<?php echo e(asset('/img/'.$list->image)); ?>" alt=""  style="width: 100px; height:100px;" /></a></td>
                            <td><?php echo e($list->description); ?></td>
                            <td><?php echo e($list->status); ?></td>
                            <td>
                                <a href="<?php echo e(url('admin/product/banner/banner/manage_banner/')); ?>/<?php echo e($list->id); ?>">
                                    <button type="button" class="btn btn-info">Edit</button>
                                </a>
                                <?php if($list->status==1): ?>
                                <a href="<?php echo e(url('admin/product/banner/banner/status/0')); ?>/<?php echo e($list->id); ?>">
                                    <button type="button" class="btn btn-success">
                                        <i class="fa fa-check" aria-hidden="true"></i>
                                    </button>
                                </a>
                                <?php elseif($list->status==0): ?>
                                <a href="<?php echo e(url('admin/product/banner/banner/status/1')); ?>/<?php echo e($list->id); ?>">
                                    <button type="button" class="btn btn-warning">
                                        <i class="fa fa-times" aria-hidden="true"></i>
                                    </button>
                                </a>
                                <?php endif; ?>
                                <a href="<?php echo e(url('admin/product/banner/banner/delete/')); ?>/<?php echo e($list->id); ?>">
                                    <button type="button" class="btn btn-danger">Delete</button>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </tbody>
                </table>
            </div>
            <!-- END DATA TABLE-->
        </div>
    </div>

    <?php if(session()->has('message')): ?>
<script>
       
iziToast.info({
    timeout: 5000,
    overlay: false,
    displayMode: 'once',
    id: 'inputs',
    zindex: 1,
    title: "<h3 class='text-danger'>Alert-:</h3>",
    message: "<h3 class='text-success'><?php echo e(session('message')); ?></h3>",
    position: 'center',
    drag: true,
});
       
    </script>
    <?php endif; ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Coffee\resources\views/admin/product/banner/banner.blade.php ENDPATH**/ ?>
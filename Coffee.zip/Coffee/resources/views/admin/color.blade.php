@extends('admin/layout')
@section('page_title','Color')
@section('color_select','active')
@section('container')



<h1 class="mb10">Color</h1>
<a href="{{url('admin/color/manage_color')}}">
    <button type="button" class="btn btn-success"> Add Color</button>
</a>
<div class="row m-t-30">
        <div class="col-md-12 col-sm-12">
            <!-- DATA TABLE-->
            <div class="table-responsive m-b-40">
                <table class="table table-borderless table-data3">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>color</th>
                            
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($data as $list)
                        <tr>
                            <td>{{$list->id}}</td>
                            <td>{{$list->color}}</td>
                            
                            <td>
                                <a href="{{url('admin/color/manage_color/')}}/{{$list->id}}">
                                    <button onclick="myFunction()" type="button" class="btn btn-info">Edit</button>
                                </a>
                                @if($list->status==1)
                                <a href="{{url('admin/color/status/0')}}/{{$list->id}}">
                                    <button onclick="myFunction()" type="button" class="btn btn-success">
                                        <i class="fa fa-check" aria-hidden="true"></i>
                                    </button>
                                </a>
                                @elseif($list->status==0)
                                <a href="{{url('admin/color/status/1')}}/{{$list->id}}">
                                    <button onclick="myFunction()" type="button" class="btn btn-warning">
                                        <i class="fa fa-times" aria-hidden="true"></i>
                                    </button>
                                </a>
                                @endif
                                <a href="{{url('admin/color/delete/')}}/{{$list->id}}">
                                    <button  onclick="myFunction()" type="button" class="btn btn-danger">Delete</button>
                                </a>
                            </td>
                        </tr>
                        @endforeach
                        
                    </tbody>
                </table>
                
<!-- <div class="sufee-alert alert with-close alert-success alert-dismissible fade show"> -->

<!-- <button type="button" class="close" data-dismiss="alert" aria-label="close">
    <span aria-hidden="true">close</span>
</button>
</div> -->



            </div>
            <!-- END DATA TABLE-->
        </div>
    </div>



    @if(session()->has('message'))
<script>
       
iziToast.info({
    timeout: 5000,
    overlay: false,
    displayMode: 'once',
    id: 'inputs',
    zindex: 1,
    title: "<h3 class='text-danger'>Alert-:</h3>",
    message: "<h3 class='text-success'>{{session('message')}}</h3>",
    position: 'center',
    drag: true,
    // inputs: [
    //     ['<input type="checkbox">', 'change', function (instance, toast, input, e) {
    //         console.info(input.checked);
    //     }],
    //     ['<input type="text">', 'keyup', function (instance, toast, input, e) {
    //         console.info(input.value);
    //     }, true],
    //     ['<input type="number">', 'keydown', function (instance, toast, input, e) {
    //         console.info(input.value);
    //     }],
    // ]
});
       
    </script>
    @endif


@endsection



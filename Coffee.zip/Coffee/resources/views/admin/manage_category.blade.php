@extends('admin/layout')
@section('page_title','Manage Category')
@section('container')


<div class="row m-t-30">
        <div class="col-md-6 col-sm-12 offset-3">
        
        <div class="card">
            <!-- <div class="card-header">Manage category</div> -->
           
            <div class="card-body">
                <!-- <div class="card-title">
                    <h3 class="text-center title-2">Pay Invoice</h3>
                </div> -->
                <!-- <hr> -->
                <form action="{{route('category.manage_category_process')}}" enctype="multipart/form-data" method="post" style="padding:30px;">
                <h1 class="mb10">Manage Category</h1>
<a href="{{url('admin/category')}}">
    <button type="button" class="btn btn-success"> Back</button><br><br><br>
</a>
                @csrf    
                <div class="form-group">
                        <label for="Category_name" class="control-label mb-1">Category Name</label>
                       <input id="Category_name" value="{{$category_name}}" name="category_name" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                       @error('category_name')
                        <div class="alert alert-danger" role="alert">
                            {{$message}}
                        </div>
                       @enderror
                    </div>
                    <div class="form-group">
                        <label for="Category_slug" class="control-label mb-1">Category Slug</label>
                        <input id="Category_slug" value="{{$category_slug}}" name="category_slug" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        @error('category_slug')
                        <div class="alert alert-danger" role="alert">
                            {{$message}}
                        </div>
                       @enderror
                    </div>  
                    <div class="form-group">
                        <label for="Image" class="control-label mb-1">image</label>
                        <input id="Image" value="{{$image}}" name="image" type="file" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        @error('image')
                        <div class="alert alert-danger" role="alert">
                            {{$message}}
                        </div>
                       @enderror
                    </div>  
                    <div class="col-lg-4 offset-4">
                        <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">Submit</button>
                    </div>
                    <input type="hidden" name="id" value="{{$id}}"/>
                </form>
            </div>
        </div>
        </div>
    </div>


@endsection
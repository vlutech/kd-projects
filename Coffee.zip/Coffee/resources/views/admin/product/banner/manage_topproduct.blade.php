@extends('admin/layout')
@section('page_title','Manage Top Product')
@section('container')


<div class="row m-t-30">
        <div class="col-md-6 col-sm-12 offset-3">
        
        <div class="card">
            
           
            <div class="card-body">
               
                <form action="{{route('product.banner.topproduct.manage_topproduct_process')}}" method="post" enctype="multipart/form-data" style="padding:30px;">
                <h1 class="mb10">Manage TopProduct</h1>
<a href="{{url('admin/product/banner/topproduct')}}">
    <button type="button" class="btn btn-success"> Back</button><br><br><br>
</a>
                @csrf    
                <div class="form-group">
                        <label for="product_Name" class="control-label mb-1">Product Name</label>
                       <input id="product_Name" value="{{$product_name}}" name="product_name" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                       @error('Product_Name')
                        <div class="alert alert-danger" role="alert">
                            {{$message}}
                        </div>
                       @enderror
                    </div>
                    <div class="form-group">
                        <label for="price" class="control-label mb-1">price</label>
                       <input id="price" value="{{$price}}" name="price" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                       @error('Price')
                        <div class="alert alert-danger" role="alert">
                            {{$message}}
                        </div>
                       @enderror
                    </div>
                    <div class="form-group">
                        <label for="Discount" class="control-label mb-1">Discount</label>
                        <input id="Discount" value="{{$discount}}" name="discount" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        @error('Discount')
                        <div class="alert alert-danger" role="alert">
                            {{$message}}
                        </div>
                       @enderror
                    </div>  
                    <div class="form-group">
                        <label for="Image" class="control-label mb-1">Image</label>
                        <input id="Image" value="{{$image}}" name="image" type="file" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        @error('Image')
                        <div class="alert alert-danger" role="alert">
                            {{$message}}
                        </div>
                       @enderror
                    </div> 
                    <div class="form-group">
                        <label for="Description" class="control-label mb-1">Description</label>
                        <input id="Description" value="{{$description}}" name="description" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        @error('Description')
                        <div class="alert alert-danger" role="alert">
                            {{$message}}
                        </div>
                       @enderror
                    </div>

                    <div class="col-lg-4 offset-4">
                        <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">Submit</button>
                    </div>
                    <input type="hidden" name="id" value="{{$id}}"/>
                </form>
            </div>
        </div>
        </div>
    </div>


@endsection
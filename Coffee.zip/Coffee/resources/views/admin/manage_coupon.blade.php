@extends('admin/layout')
@section('page_title','Manage Coupon')
@section('coupon_select','active')
@section('container')


<div class="row m-t-30">
        <div class="col-md-6 col-sm-12 offset-3">
        
        <div class="card">
            <!-- <div class="card-header">Manage category</div> -->
           
            <div class="card-body">
                <!-- <div class="card-title">
                    <h3 class="text-center title-2">Pay Invoice</h3>
                </div> -->
                <!-- <hr> -->
                <form action="{{route('coupon.manage_coupon_process')}}" method="post" style="padding:30px;">
                <h1 class="mb10">Manage Coupon</h1>
<a href="{{url('admin/coupon')}}">
    <button type="button" class="btn btn-success"> Back</button><br><br><br>
</a>
                @csrf    
                <div class="form-group">
                        <label for="title" class="control-label mb-1">Title</label>
                       <input id="title" value="{{$title}}" name="title" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                       @error('title')
                        <div class="alert alert-danger" role="alert">
                            {{$message}}
                        </div>
                       @enderror
                    </div>
                    <div class="form-group">
                        <label for="code" class="control-label mb-1">Code</label>
                        <input id="code" value="{{$code}}" name="code" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        @error('code')
                        <div class="alert alert-danger" role="alert">
                            {{$message}}
                        </div>
                       @enderror
                    </div>  
                    <div class="form-group">
                        <label for="value" class="control-label mb-1">Value</label>
                        <input id="value" value="{{$value}}" name="value" type="text" class="form-control" aria-required="true" aria-invalid="false" required><br>
                        @error('value')
                        <div class="alert alert-danger" role="alert">
                            {{$message}}
                        </div>
                       @enderror
                    </div>  
                    <div class="col-lg-4 offset-4">
                        <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">Submit</button>
                    </div>
                    <input type="hidden" name="id" value="{{$id}}"/>
                </form>
            </div>
        </div>
        </div>
    </div>


@endsection
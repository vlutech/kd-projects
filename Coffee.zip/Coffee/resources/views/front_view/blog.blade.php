@extends('front_view/layout')

<section class="blogs" id="blogs">

    <h1 class="heading"> our <span>blogs</span> </h1>

    <div class="box-container">
@foreach($home_blogs as $list)
        <div class="box">
            <div class="image">
                <img src="{{asset('img/'.$list->image)}}" alt="">
            </div>
            <div class="content">
                <a href="#" class="title">{{$list->Title}}</a>
                <span>by admin / {{$list->created_at}}</span>
                <p>{{$list->description}}</p>
                <a href="#" class="btn">read more</a>
            </div>
        </div>
@endforeach
       

    </div>

</section>
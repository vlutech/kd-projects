
<?php
session_start();
include('connection.php');
error_reporting(0);
$message="";
if(isset($_POST['submit']))
{
    $username=$_POST["username"];
    $password=$_POST["password"];

    $sql = "SELECT * FROM admin where username='$username' and  password='$password'";

    $data = mysqli_query($conn, $sql);
    $total = mysqli_num_rows($data);
    if($total==1)
    {
        $_SESSION['user_name']=$username;
        header('location:dashboard/home.php');
    }

    else{$message="please enter correct username and password";}
}





?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
    
    <title>Document</title>
</head>
<body style="background-color: #198754;">
    <div class="container">
        <div class="row">
            <div class="col-lg3 col-md-3 col-sm-3"></div>
            <div class="col-lg6 col-md-6 col-sm-6" style="background-color: #ced4da;;margin:10% 25%;padding:5% 5%;">
               <h3 align="center"><u>Login Form</u></h3> <br>
                <form action="" method="post" align=center>
                    <input type="text" class="form-control" name="username" placeholder="username" required><br><br>
                    <input type="password" class="form-control" name="password" placeholder="password" required><br><br>
                    <button type="submit" name="submit" style="background-color: blue; border-radius:5px; color:white;">Submit</button>
                    <h5><?php error_reporting(0); if($message!="") {echo $message;} ?></h5>
                </form>
            </div>
            <div class="col-lg3 col-md-3 col-sm-3"></div>
        </div>
    </div>
</body>
</html>







<?php
include('../connection.php');
include('../database.php');
session_start();
$userprofile = $_SESSION['user_name'];
if($userprofile==true)
{

}
else{
    header('Location:../admin.php');
}

$query = "SELECT image from admin WHERE username='$userprofile'";
    $data = mysqli_query($conn, $query);
    $result=mysqli_fetch_assoc($data);
    $img= $result['image'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--Boxicon cdn link-->
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>

    <!--bootstrap cdn  --->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

    <title>Drop down sidebar menu</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="../css/style.css">

    <style>input[type="file"] {
    display: none;
}
input[type="submit"]
{
	background-color: blueviolet;
	width:80px;
	height:30px;
	font-size: 15px;
}
.custom-file-upload {
    border: 1px solid #ccc;
    display: inline-block;
    padding: 6px 12px;
    cursor: pointer;
	background-color: #007bff;
	border-radius: 5px;
	font-weight: 900;
}</style>
</head>
<body>
    <div class="sidebar">
<!--
        <div class="logo-details">
            <i class='bx bxl-c-plus-plus'></i>
            
            <span class="logo_name">Vlu_Tech</span>
        </div>
-->
        <ul class="nav-links">
            <li>
                <div class="profile-details">
                    <div class="profile-content">
                        <img src="<?php echo $img;?>" alt="profile">
                    </div>
                    <div class="name-job">
                        <div class="profile_name"><?php echo $userprofile; ?></div>
                    </div>
                </div>
            </li>
            <li>
                <div class="iocn-link">
                    <a href="">
                        <i class='bx bx-collection'></i>
                        <span class="link_name">Category</span>
                    </a>
                    <i class='bx bxs-chevron-down arrow'></i>
                </div>
                <ul class="sub-menu">
                    <li><a class="link_name" href="">Category</a></li>
                    <li><a href="">HTML & CSS</a></li>
                    <li><a href="">Javascript</a></li>
                    <li><a href="">PHP & Mysql</a></li>
                </ul>
            </li>
            <li>
                <div class="iocn-link">
                    <a href="">
                        <i class='bx bx-book-alt'></i>
                        <span class="link_name">Post</span>
                    </a>
                    <i class='bx bxs-chevron-down arrow'></i>
                </div>
                <ul class="sub-menu">
                    <li><a class="link_name" href="">Post</a></li>
                    <li><a href="">Web Design</a></li>
                    <li><a href="">Login Form</a></li>
                    <li><a href="">Card Design</a></li>
                </ul>
            </li>
            <li>
                <div class="iocn-link">
                    <a href="">
                        <i class='bx bx-plug' ></i>
                        <span class="link_name">Plugins</span>
                    </a>
                    <i class='bx bxs-chevron-down arrow'></i>
                </div>
                <ul class="sub-menu">
                    <li><a class="link_name" href="">Plugins</a></li>
                    <li><a href="">UI FACE</a></li>
                    <li><a href="">Pigments</a></li>
                    <li><a href="">Box Icons</a></li>
                </ul>
            </li>
            <li>
                <a href="home.php">
                    <i class='bx bx-pie-chart-alt-2'></i>
                    <span class="link_name">Home</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="">Home</a></li>
                </ul>
            </li>
            <li class="active bg-primary">
                <a href="dishes.php">
                    <i class='bx bx-line-chart'></i>
                    <span class="link_name">Dishes</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="">dishes</a></li> 
                </ul>
            </li>
            
            <li>
                <a href="about.php">
                    <i class='bx bx-compass'></i>
                    <span class="link_name">About</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="">About</a></li> 
                </ul>
            </li>
            <li>
                <a href="menu.php">
                    <i class='bx bx-history' ></i>
                    <span class="link_name">Menu</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="">Menu</a></li> 
                </ul>
            </li>
            <li>
                <a href="review.php">
                    <i class='bx bx-cog' ></i>
                    <span class="link_name">Review</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="">Review</a></li> 
                </ul>
            </li>
            <li>
                <a href="order.php">
                    <i class='bx bx-cog' ></i>
                    <span class="link_name">Order</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="">Order</a></li> 
                </ul>
            </li>
            <li class="logout" style="position:fixed;bottom:10px;">
                <a href="logout.php">
                    <i class='bx bx-log-out'></i>
                    <span class="link_name">Logout</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="">Logout</a></li> 
                </ul>
            </li>
        </ul>
    </div>
    <section class="home-section">
    <?php include('header.php'); ?>
        <div class="home-content" style="z-index: 1000;">
            <i class='bx bx-menu'></i>
            <span class="text"></span>
        </div>

        <section class="dishes" id="dishes">

    <h3 class="sub-heading"> our dishes </h3>
    <h1 class="heading"> popular dishes </h1>

    <div class="box-container">

        <div class="box">
            <a href="#" class="fas fa-heart"></a>
            <a href="#" class="fas fa-eye"></a>
            <img src="<?php echo $pic1; ?>" alt="#">
            
            <h3>tasty food</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <span>$15.99</span>
            
            <a href="#" class="btn"><form action="" method="POST" enctype="multipart/form-data" align=center>
              											<label class="custom-file-upload">
              												<input type="file" name="uploadfile1"/>upload
              											</label>
              												<br>
                											<input type="submit" name="upload1">
              										</form></a>
        </div>

        <div class="box">
            <a href="#" class="fas fa-heart"></a>
            <a href="#" class="fas fa-eye"></a>
            <img src="<?php echo $pic2; ?>" alt="">
            <h3>tasty food</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <span>$15.99</span>
            <a href="#" class="btn"> <form action="" method="POST" enctype="multipart/form-data" align=center>
              											<label class="custom-file-upload">
              												<input type="file" name="uploadfile2"/>upload
              											</label>
              												<br>
                											<input type="submit" name="upload2">
              										</form></a>
        </div>

        <div class="box">
            <a href="#" class="fas fa-heart"></a>
            <a href="#" class="fas fa-eye"></a>
            <img src="<?php echo $pic3; ?>" alt="">
            <h3>tasty food</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <span>$15.99</span>
            <a href="#" class="btn"> <form action="" method="POST" enctype="multipart/form-data" align=center>
              											<label class="custom-file-upload">
              												<input type="file" name="uploadfile3"/>upload
              											</label>
              												<br>
                											<input type="submit" name="upload3">
              										</form></a>
        </div>

        <div class="box">
            <a href="#" class="fas fa-heart"></a>
            <a href="#" class="fas fa-eye"></a>
            <img src="<?php echo $pic4; ?>" alt="">
            <h3>tasty food</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <span>$15.99</span>
            <a href="#" class="btn"> <form action="" method="POST" enctype="multipart/form-data" align=center>
              											<label class="custom-file-upload">
              												<input type="file" name="uploadfile4"/>upload
              											</label>
              												<br>
                											<input type="submit" name="upload4">
              										</form></a>
        </div>

        <div class="box">
            <a href="#" class="fas fa-heart"></a>
            <a href="#" class="fas fa-eye"></a>
            <img src="<?php echo $pic5; ?>" alt="">
            <h3>tasty food</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <span>$15.99</span>
            <a href="#" class="btn"> <form action="" method="POST" enctype="multipart/form-data" align=center>
              											<label class="custom-file-upload">
              												<input type="file" name="uploadfile5"/>upload
              											</label>
              												<br>
                											<input type="submit" name="upload5">
              										</form></a>
        </div>

        <div class="box">
            <a href="#" class="fas fa-heart"></a>
            <a href="#" class="fas fa-eye"></a>
            <img src="<?php echo $pic6; ?>" alt="">
            <h3>tasty food</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <span>$15.99</span>
            <a href="#" class="btn"> <form action="" method="POST" enctype="multipart/form-data" align=center>
              											<label class="custom-file-upload">
              												<input type="file" name="uploadfile6"/>upload
              											</label>
              												<br>
                											<input type="submit" name="upload6">
              										</form></a>
        </div>

    </div>

</section>

    </section>
    <script>
        let arrow = document.querySelectorAll(".arrow");
        
        for (var i=0; i < arrow.length; i++){
            arrow[i].addEventListener("click",(e)=>{
                let arrowParent = e.target.parentElement.parentElement;
                arrowParent.classList.toggle("showMenu");
            });
        }
        let sidebar = document.querySelector(".sidebar");
        let sidebarBtn = document.querySelector(".bx-menu");
        console.log(sidebarBtn);
        sidebarBtn.addEventListener("click",()=>{
            sidebar.classList.toggle("close");
        });
    </script>
    <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="../js/script.js"></script>
</body>
</html>
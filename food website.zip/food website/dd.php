<?php 
include('connection.php');

$sql="SELECT * FROM product WHERE id = 30";
$result = mysqli_query($conn,$sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $pic = $row["image"]; 
	  
    }
  } 

$sql="SELECT * FROM product WHERE id = 1";
$result = mysqli_query($conn,$sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $pic1 = $row["image"]; 
	  
    }
  } 

$sql="SELECT * FROM product WHERE id = 2";
$result = mysqli_query($conn,$sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $pic2 = $row["image"]; 
	  
    }
  } 

  $sql="SELECT * FROM product WHERE id = 3";
$result = mysqli_query($conn,$sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $pic3 = $row["image"]; 
	  
    }
  } 

  $sql="SELECT * FROM product WHERE id = 4";
$result = mysqli_query($conn,$sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $pic4 = $row["image"]; 
	  
    }
  } 

  $sql="SELECT * FROM product WHERE id = 5";
$result = mysqli_query($conn,$sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $pic5 = $row["image"]; 
	  
    }
  } 

  $sql="SELECT * FROM product WHERE id = 6";
$result = mysqli_query($conn,$sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $pic6 = $row["image"]; 
	  
    }
  } 

  $sql="SELECT * FROM product WHERE id = 7";
$result = mysqli_query($conn,$sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $pic7 = $row["image"]; 
	  
    }
  } 

  $sql="SELECT * FROM product WHERE id = 8";
$result = mysqli_query($conn,$sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $pic8 = $row["image"]; 
	  
    }
  } 

  $sql="SELECT * FROM product WHERE id = 9";
$result = mysqli_query($conn,$sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $pic9 = $row["image"]; 
	  
    }
  } 

  $sql="SELECT * FROM product WHERE id = 10";
$result = mysqli_query($conn,$sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $pic10 = $row["image"]; 
	  
    }
  } 

  $sql="SELECT * FROM product WHERE id = 11";
$result = mysqli_query($conn,$sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $pic11 = $row["image"]; 
	  
    }
  } 

  $sql="SELECT * FROM product WHERE id = 12";
$result = mysqli_query($conn,$sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $pic12 = $row["image"]; 
	  
    }
  } 

  $sql="SELECT * FROM product WHERE id = 13";
$result = mysqli_query($conn,$sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $pic13 = $row["image"]; 
	  
    }
  } 

  $sql="SELECT * FROM product WHERE id = 14";
$result = mysqli_query($conn,$sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $pic14 = $row["image"]; 
	  
    }
  } 

  $sql="SELECT * FROM product WHERE id = 15";
$result = mysqli_query($conn,$sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $pic15 = $row["image"]; 
	  
    }
  } 

  $sql="SELECT * FROM product WHERE id = 16";
$result = mysqli_query($conn,$sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $pic16 = $row["image"]; 
	  
    }
  } 

  $sql="SELECT * FROM product WHERE id = 17";
$result = mysqli_query($conn,$sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $pic17 = $row["image"]; 
	  
    }
  } 

  $sql="SELECT * FROM product WHERE id = 18";
$result = mysqli_query($conn,$sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $pic18 = $row["image"]; 
	  
    }
  } 

  $sql="SELECT * FROM product WHERE id = 19";
$result = mysqli_query($conn,$sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $pic19 = $row["image"]; 
	  
    }
  } 

  $sql="SELECT * FROM product WHERE id = 20";
$result = mysqli_query($conn,$sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $pic20 = $row["image"]; 
	  
    }
  } 

  $sql="SELECT * FROM product WHERE id = 21";
$result = mysqli_query($conn,$sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $pic21 = $row["image"]; 
	  
    }
  } 

  $sql="SELECT * FROM product WHERE id = 22";
$result = mysqli_query($conn,$sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $pic22 = $row["image"]; 
	  
    }
  } 

  $sql="SELECT * FROM product WHERE id = 23";
$result = mysqli_query($conn,$sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $pic23 = $row["image"]; 
	  
    }
  } 

  $sql="SELECT * FROM product WHERE id = 24";
$result = mysqli_query($conn,$sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $pic24 = $row["image"]; 
	  
    }
  } 

  $sql="SELECT * FROM product WHERE id = 25";
$result = mysqli_query($conn,$sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $pic25 = $row["image"]; 
	  
    }
  } 

  $sql="SELECT * FROM product WHERE id = 26";
$result = mysqli_query($conn,$sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $pic26 = $row["image"]; 
	  
    }
  } 

  $sql="SELECT * FROM product WHERE id = 27";
$result = mysqli_query($conn,$sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $pic27 = $row["image"]; 
	  
    }
  } 

  $sql="SELECT * FROM product WHERE id = 28";
$result = mysqli_query($conn,$sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $pic28 = $row["image"]; 
	  
    }
  } 

  $sql="SELECT * FROM product WHERE id = 29";
$result = mysqli_query($conn,$sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $pic29 = $row["image"]; 
	  
    }
  } 
?>






<?php
if (isset($_POST['upload'])) {

	$filename = $_FILES["uploadfile"]["name"];
	$tempname = $_FILES["uploadfile"]["tmp_name"];	
		$folder = "../images/".$filename;
		$sql = "UPDATE product SET image='$folder' where id=30";
		mysqli_query($conn, $sql);
}

if (isset($_POST['upload1'])) {

	$filename = $_FILES["uploadfile1"]["name"];
	$tempname = $_FILES["uploadfile1"]["tmp_name"];	
		$folder = "images/".$filename;
		$sql = "UPDATE product SET image='$folder' where id=1";
		mysqli_query($conn, $sql);
}

if (isset($_POST['upload2'])) {

	$filename = $_FILES["uploadfile2"]["name"];
	$tempname = $_FILES["uploadfile2"]["tmp_name"];	
		$folder = "../images/".$filename;
		$sql = "UPDATE product SET image='$folder' where id=2";
		mysqli_query($conn, $sql);
}

if (isset($_POST['upload3'])) {

	$filename = $_FILES["uploadfile3"]["name"];
	$tempname = $_FILES["uploadfile3"]["tmp_name"];	
		$folder = "../images/".$filename;
		$sql = "UPDATE product SET image='$folder' where id=3";
		mysqli_query($conn, $sql);
}

if (isset($_POST['upload4'])) {

	$filename = $_FILES["uploadfile4"]["name"];
	$tempname = $_FILES["uploadfile4"]["tmp_name"];	
		$folder = "../images/".$filename;
		$sql = "UPDATE product SET image='$folder' where id=4";
		mysqli_query($conn, $sql);
}

if (isset($_POST['upload5'])) {

	$filename = $_FILES["uploadfile5"]["name"];
	$tempname = $_FILES["uploadfile5"]["tmp_name"];	
		$folder = "../images/".$filename;
		$sql = "UPDATE product SET image='$folder' where id=5";
		mysqli_query($conn, $sql);
}

if (isset($_POST['upload6'])) {

	$filename = $_FILES["uploadfile6"]["name"];
	$tempname = $_FILES["uploadfile6"]["tmp_name"];	
		$folder = "../images/".$filename;
		$sql = "UPDATE product SET image='$folder' where id=6";
		mysqli_query($conn, $sql);
}

if (isset($_POST['upload7'])) {

	$filename = $_FILES["uploadfile7"]["name"];
	$tempname = $_FILES["uploadfile7"]["tmp_name"];	
		$folder = "../images/".$filename;
		$sql = "UPDATE product SET image='$folder' where id=7";
		mysqli_query($conn, $sql);
}

if (isset($_POST['upload8'])) {

	$filename = $_FILES["uploadfile8"]["name"];
	$tempname = $_FILES["uploadfile8"]["tmp_name"];	
		$folder = "../images/".$filename;
		$sql = "UPDATE product SET image='$folder' where id=8";
		mysqli_query($conn, $sql);
}

if (isset($_POST['upload9'])) {

	$filename = $_FILES["uploadfile9"]["name"];
	$tempname = $_FILES["uploadfile9"]["tmp_name"];	
		$folder = "../images/".$filename;
		$sql = "UPDATE product SET image='$folder' where id=9";
		mysqli_query($conn, $sql);
}

if (isset($_POST['upload10'])) {

	$filename = $_FILES["uploadfile10"]["name"];
	$tempname = $_FILES["uploadfile10"]["tmp_name"];	
		$folder = "../images/".$filename;
		$sql = "UPDATE product SET image='$folder' where id=10";
		mysqli_query($conn, $sql);
}

if (isset($_POST['upload11'])) {

	$filename = $_FILES["uploadfile11"]["name"];
	$tempname = $_FILES["uploadfile11"]["tmp_name"];	
		$folder = "../images/".$filename;
		$sql = "UPDATE product SET image='$folder' where id=11";
		mysqli_query($conn, $sql);
}

if (isset($_POST['upload12'])) {

	$filename = $_FILES["uploadfile12"]["name"];
	$tempname = $_FILES["uploadfile12"]["tmp_name"];	
		$folder = "../images/".$filename;
		$sql = "UPDATE product SET image='$folder' where id=12";
		mysqli_query($conn, $sql);
}

if (isset($_POST['upload13'])) {

	$filename = $_FILES["uploadfile13"]["name"];
	$tempname = $_FILES["uploadfile13"]["tmp_name"];	
		$folder = "../images/".$filename;
		$sql = "UPDATE product SET image='$folder' where id=13";
		mysqli_query($conn, $sql);
}

if (isset($_POST['upload14'])) {

	$filename = $_FILES["uploadfile14"]["name"];
	$tempname = $_FILES["uploadfile14"]["tmp_name"];	
		$folder = "../images/".$filename;
		$sql = "UPDATE product SET image='$folder' where id=14";
		mysqli_query($conn, $sql);
}

if (isset($_POST['upload15'])) {

	$filename = $_FILES["uploadfile15"]["name"];
	$tempname = $_FILES["uploadfile15"]["tmp_name"];	
		$folder = "../images/".$filename;
		$sql = "UPDATE product SET image='$folder' where id=15";
		mysqli_query($conn, $sql);
}

if (isset($_POST['upload16'])) {

	$filename = $_FILES["uploadfile16"]["name"];
	$tempname = $_FILES["uploadfile16"]["tmp_name"];	
		$folder = "../images/".$filename;
		$sql = "UPDATE product SET image='$folder' where id=16";
		mysqli_query($conn, $sql);
}

if (isset($_POST['upload17'])) {

	$filename = $_FILES["uploadfile17"]["name"];
	$tempname = $_FILES["uploadfile17"]["tmp_name"];	
		$folder = "../images/".$filename;
		$sql = "UPDATE product SET image='$folder' where id=17";
		mysqli_query($conn, $sql);
}

if (isset($_POST['upload18'])) {

	$filename = $_FILES["uploadfile18"]["name"];
	$tempname = $_FILES["uploadfile18"]["tmp_name"];	
		$folder = "../images/".$filename;
		$sql = "UPDATE product SET image='$folder' where id=18";
		mysqli_query($conn, $sql);
}

if (isset($_POST['upload19'])) {

	$filename = $_FILES["uploadfile19"]["name"];
	$tempname = $_FILES["uploadfile19"]["tmp_name"];	
		$folder = "../images/".$filename;
		$sql = "UPDATE product SET image='$folder' where id=19";
		mysqli_query($conn, $sql);
}

if (isset($_POST['upload20'])) {

	$filename = $_FILES["uploadfile20"]["name"];
	$tempname = $_FILES["uploadfile20"]["tmp_name"];	
		$folder = "../images/".$filename;
		$sql = "UPDATE product SET image='$folder' where id=20";
		mysqli_query($conn, $sql);
}

if (isset($_POST['upload21'])) {

	$filename = $_FILES["uploadfile21"]["name"];
	$tempname = $_FILES["uploadfile21"]["tmp_name"];	
		$folder = "../images/".$filename;
		$sql = "UPDATE product SET image='$folder' where id=21";
		mysqli_query($conn, $sql);
}

if (isset($_POST['upload22'])) {

	$filename = $_FILES["uploadfile22"]["name"];
	$tempname = $_FILES["uploadfile22"]["tmp_name"];	
		$folder = "../images/".$filename;
		$sql = "UPDATE product SET image='$folder' where id=22";
		mysqli_query($conn, $sql);
}

if (isset($_POST['upload23'])) {

	$filename = $_FILES["uploadfile23"]["name"];
	$tempname = $_FILES["uploadfile23"]["tmp_name"];	
		$folder = "../images/".$filename;
		$sql = "UPDATE product SET image='$folder' where id=23";
		mysqli_query($conn, $sql);
}

if (isset($_POST['upload24'])) {

	$filename = $_FILES["uploadfile24"]["name"];
	$tempname = $_FILES["uploadfile24"]["tmp_name"];	
		$folder = "../images/".$filename;
		$sql = "UPDATE product SET image='$folder' where id=24";
		mysqli_query($conn, $sql);
}

if (isset($_POST['upload25'])) {

	$filename = $_FILES["uploadfile25"]["name"];
	$tempname = $_FILES["uploadfile25"]["tmp_name"];	
		$folder = "../images/".$filename;
		$sql = "UPDATE product SET image='$folder' where id=25";
		mysqli_query($conn, $sql);
}

if (isset($_POST['upload26'])) {

	$filename = $_FILES["uploadfile26"]["name"];
	$tempname = $_FILES["uploadfile26"]["tmp_name"];	
		$folder = "../images/".$filename;
		$sql = "UPDATE product SET image='$folder' where id=26";
		mysqli_query($conn, $sql);
}

if (isset($_POST['upload27'])) {

	$filename = $_FILES["uploadfile27"]["name"];
	$tempname = $_FILES["uploadfile27"]["tmp_name"];	
		$folder = "../images/".$filename;
		$sql = "UPDATE product SET image='$folder' where id=27";
		mysqli_query($conn, $sql);
}

if (isset($_POST['upload28'])) {

	$filename = $_FILES["uploadfile28"]["name"];
	$tempname = $_FILES["uploadfile28"]["tmp_name"];	
		$folder = "../images/".$filename;
		$sql = "UPDATE product SET image='$folder' where id=28";
		mysqli_query($conn, $sql);
}

if (isset($_POST['upload29'])) {

	$filename = $_FILES["uploadfile29"]["name"];
	$tempname = $_FILES["uploadfile29"]["tmp_name"];	
		$folder = "../images/".$filename;
		$sql = "UPDATE product SET image='$folder' where id=29";
		mysqli_query($conn, $sql);
}


?>

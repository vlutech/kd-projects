<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="{{asset('site-assets/css/style.css')}}" type="text/css">
    <link rel="stylesheet" href="{{asset('site-assets/css/style-1.css')}}" type="text/css">
    <link rel="stylesheet" href="{{asset('site-assets/css/style-2.css')}}" type="text/css">
    <link rel="stylesheet" href="{{asset('site-assets/css/style-3.css')}}" type="text/css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script><title>OUR NEW LARAVEL PROJECT</title>
<script type="text/javascript" href="{{asset('site-assets/js/main.js')}}"></script>
<script type="text/javascript" href="{{asset('site-assets/js/main-1.js')}}"></script>
<script type="text/javascript" href="{{asset('site-assets/js/main-2.js')}}"></script>
<script type="text/javascript" href="{{asset('site-assets/js/main-3.js')}}"></script>
<script type="text/javascript" href="{{asset('site-assets/js/main-4.js')}}"></script>
<script type="text/javascript" href="{{asset('site-assets/js/main-5.js')}}"></script>

    





<link href="{{asset('site-assets/css/font-awesome.css')}}" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="{{asset('site-assets/css/bootstrap.css')}}" rel="stylesheet">   
    <!-- SmartMenus jQuery Bootstrap Addon CSS -->
    <link href="{{asset('site-assetscss/jquery.smartmenus.bootstrap.css')}}" rel="stylesheet">
    <!-- Product view slider -->
    <link rel="stylesheet" type="text/css" href="{{asset('site-assets/css/jquery.simpleLens.css')}}">    
    <!-- slick slider -->
    <link rel="stylesheet" type="text/css" href="{{asset('site-assets/css/slick.css')}}">
    <!-- price picker slider -->
    <link rel="stylesheet" type="text/css" href="{{asset('site-assets/css/nouislider.css')}}">
    <!-- Theme color -->
    <link id="switcher" href="{{asset('site-assets/css/theme-color/default-theme.css')}}" rel="stylesheet">
    <!-- <link id="switcher" href="css/theme-color/bridge-theme.css" rel="stylesheet"> -->
    <!-- Top Slider CSS -->
    <link href="{{asset('site-assets/css/sequence-theme.modern-slide-in.css')}}" rel="stylesheet" media="all">

    <!-- Main style sheet -->
    <link href="{{asset('site-assets/css/style.css')}}" rel="stylesheet">    

    <!-- Google Font -->
    <link href='https://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Raleway' rel='stylesheet' type='text/css'>
    






   
    <link rel='stylesheet' id='alt-construction-estate-pro-font-css' href='//fonts.googleapis.com/css?family=PT+Sans%3A300%2C400%2C600%2C700%2C800%2C900%7CRoboto%3A400%2C700%7CRoboto+Condensed%3A400%2C700%7COpen+Sans%7COverpass%7CMontserrat%3A300%2C400%2C600%2C700%2C800%2C900%7CPlayball%3A300%2C400%2C600%2C700%2C800%2C900%7CAlegreya%3A300%2C400%2C600%2C700%2C800%2C900%7CJulius+Sans+One%7CArsenal%7CSlabo%7CLato%7COverpass+Mono%7CSource+Sans+Pro%7CRaleway%7CMerriweather%7CRubik%7CLora%7CUbuntu%7CCabin%7CArimo%7CPlayfair+Display%7CQuicksand%7CPadauk%7CMuli%7CInconsolata%7CBitter%7CPacifico%7CIndie+Flower%7CVT323%7CDosis%7CFrank+Ruhl+Libre%7CFjalla+One%7COxygen%7CArvo%7CNoto+Serif%7CLobster%7CCrimson+Text%7CYanone+Kaffeesatz%7CAnton%7CLibre+Baskerville%7CBree+Serif%7CGloria+Hallelujah%7CJosefin+Sans%7CAbril+Fatface%7CVarela+Round%7CVampiro+One%7CShadows+Into+Light%7CCuprum%7CRokkitt%7CVollkorn%7CFrancois+One%7COrbitron%7CPatua+One%7CAcme%7CSatisfy%7CJosefin+Slab%7CQuattrocento+Sans%7CArchitects+Daughter%7CRusso+One%7CMonda%7CRighteous%7CLobster+Two%7CHammersmith+One%7CCourgette%7CPermanent+Marker%7CCherry+Swash%7CCormorant+Garamond%7CPoiret+One%7CBenchNine%7CEconomica%7CHandlee%7CCardo%7CAlfa+Slab+One%7CAveria+Serif+Libre%7CCookie%7CChewy%7CGreat+Vibes%7CComing+Soon%7CPhilosopher%7CDays+One%7CKanit%7CShrikhand%7CTangerine%7CIM+Fell+English+SC%7CBoogaloo%7CBangers%7CFredoka+One%7CBad+Script%7CVolkhov%7CShadows+Into+Light+Two%7CMarck+Script%7CSacramento%7CPoppins&#038;ver=5.8.1'
        media='all' />
    <style>
 #aa-slider {
  float: left;
  display: inline;
  width: 100%;
}
#aa-slider .aa-slider-area {
  display: inline;
  float: left;
  width: 100%;
}
#aa-slider .aa-slider-area .seq-title {
  left: 19%;
  margin-right: 0;
  position: absolute;
  top: 30%;
  width: 57%;
  text-align: center;
}
#aa-slider .aa-slider-area .seq-title span {
  background-color: #fff;  
  display: inline-block;
  padding: 6px 15px;
  text-transform: uppercase;
  letter-spacing: 1.5px;
  margin-bottom: 10px;
}
#aa-slider .aa-slider-area .seq-title h2 {
  background-color: rgba(255, 255, 255, 0.6);
  color: #333;
  display: inline-block;
  float: none;
  font-size: 50px;
  font-family: "Raleway", sans-serif;
  font-weight: bold;
  margin-top: 20px;
  text-align: center;
  text-transform: uppercase;
  width: 100%;
}
#aa-slider .aa-slider-area .seq-title p {
  color: #fff;
  display: block;
  text-align: center;
  letter-spacing: 0.5px;
}
#aa-slider .aa-slider-area .seq-title .aa-shop-now-btn {
  margin-top: 25px;
}
#aa-slider .aa-slider-area .seq .seq-next {
  -webkit-transition: all 0.5s;
  -moz-transition: all 0.5s;
  -ms-transition: all 0.5s;
  -o-transition: all 0.5s;
  transition: all 0.5s;
}
#aa-slider .aa-slider-area .seq .seq-next:hover, #aa-slider .aa-slider-area .seq .seq-next:focus {  
  border: 1px solid #f9f9f9;
  color: #fff;
}
#aa-slider .aa-slider-area .seq .seq-prev {
  -webkit-transition: all 0.5s;
  -moz-transition: all 0.5s;
  -ms-transition: all 0.5s;
  -o-transition: all 0.5s;
  transition: all 0.5s;
}
#aa-slider .aa-slider-area .seq .seq-prev:hover, #aa-slider .aa-slider-area .seq .seq-prev:focus {
  border: 1px solid #f9f9f9;
  color: #fff;
}

    </style>
</head>
<body class="home page-template page-template-page-template page-template-home-page page-template-page-templatehome-page-php page page-id-40279 theme-alt-construction-estate-pro woocommerce-no-js elementor-beta elementor-default elementor-kit-40322">
<header id="masthead" class="site-header">
        <div id="header">
            <div class="container-fluid">
                <div class="row m-0">
                    <div class="logobox col-md-3 col-sm-12 col-12 p-0">
                        <div class="top_social">
                            <div class="socialbox">
                                <a class="twitter" href="https://twitter.com/" target="_blank"><i class="fab fa-twitter align-middle" aria-hidden="true"></i></a>
                                <a class="insta" href="https://www.instagram.com" target="_blank"><i class="fab fa-instagram align-middle" aria-hidden="true"></i></a>
                                <a class="facebook" href="https://www.facebook.com/" target="_blank"><i class="fab fa-facebook-f align-middle " aria-hidden="true"></i></a>
                                <a class="youtube" href="https://www.youtube.com" target="_blank"><i class="fab fa-youtube align-middle" aria-hidden="true"></i></a>
                                <a class="pintrest" href="https://www.pinterest.com/" target="_blank"><i class="fab fa-pinterest-p align-middle " aria-hidden="true"></i></a>
                                <a class="linkedin" href="https://www.linkedin.com" target="_blank"><i class="fab fa-linkedin-in align-middle" aria-hidden="true"></i></a>
                                <a class="tumbler" href="https://www.tumblr.com/" target="_blank"><i class="fab fa-tumblr align-middle" aria-hidden="true"></i></a>
                                <a class="gplus" href="https://plus.google.com/" target="_blank"><i class="fab fa-google-plus-g align-middle" aria-hidden="true"></i></a>
                                <a class="flicker" href="https://www.flickr.com/" target="_blank"><i class="fab fa-flickr align-middle " aria-hidden="true"></i></a>
                                <a class="vk" href="https://vk.com/" target="_blank"><i class="fab fa-vk align-middle " aria-hidden="true"></i></a>
                            </div>
                        </div>
                        <div class="logo">
                            <h1 class="text-sm-center"><a href="" rel="home">Vlutech </a></h1>
                            <p class="site-description">Equipments (I) Pvt. Ltd.</p>
                        </div>
                    </div>
                    <div class="contact_details col-md-9">
                        <div class="row head float-right w-100 mb-3">
                            <div class="col-lg-3 col-md-6 col-sm-6 small_media">
                                <div class="address media">
                                    <i class="fas fa-street-view d-flex align-self-start" aria-hidden="true"></i>
                                    <div class="media-body">
                                        <p class="font-weight-bold hi_bold">Our Address</p>
                                        <p class="hi_normal">New Delhi, India</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 small_media">
                                <div class="address media">
                                    <i class="fas fa-phone-volume d-flex align-self-start" aria-hidden="true"></i>
                                    <div class="media-body">
                                        <p class="font-weight-bold hi_bold">Call Us Any Time</p>
                                        <p class="hi_normal">+91-9871061108 +91-9810626700</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 small_media">
                                <div class="address media">
                                    <i class="far fa-envelope-open d-flex align-self-start" aria-hidden="true"></i>
                                    <div class="media-body">
                                        <p class="font-weight-bold hi_bold">Send An Email</p>
                                        <p class="hi_normal">s&#097;l&#101;&#115;&#064;&#115;unl&#097;&#098;t&#101;&#099;h&#046;&#099;om&#032;&#105;nf&#111;&#064;&#115;u&#110;lab&#116;&#101;c&#104;.&#099;&#111;&#109;</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 small_media">
                                <div class="address media">
                                    <i class="far fa-clock d-flex align-self-start" aria-hidden="true"></i>
                                    <div class="media-body">
                                        <p class="font-weight-bold hi_bold">Working Time</p>
                                        <p class="hi_normal">Mon To Sat 9AM to 9PM</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="menubar float-left w-100 m-0">
                            <div class="row m-0 inner_menu">
                                <div class="innermenubox p-md-0 col-md-11 col-11">
                                    <div id="mySidenav" class="nav">
                                        <div class="toggle-nav">
                                            <span></span>
                                        </div>
                                        <nav id="site-navigation" class="main-navigation">
                                            <div class="menu clearfix">
                                                <ul id="menu-home" class="clearfix">
                                                    <li id="menu-item-148" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-has-children menu-item-148"><a href="https://sunlabtech.com/" aria-current="page">Home</a>
                                                        <ul class="sub-menu">
                                                            <li id="menu-item-150" class="menu-item"><a href="">About us</a></li>
                                                            <li id="menu-item-354" class="menu-item"><a href="">Vision and Values</a></li>
                                                            <li id="menu-item-353" class="menu-item"><a href="">Our Mission</a></li>
                                                            <li id="menu-item-149" class="menu-item"><a href="">Our team</a></li>
                                                        </ul>
                                                    </li>
                                                    <li id="menu-item-151" class="menu-item"><a href="">Lab Equipments</a>
                                                        <ul class="sub-menu">
                                                            <li id="menu-item-152" class="menu-item"><a href="">Civil Engineering Lab Equipment</a>
                                                                <ul class="sub-menu">
                                                                    <li id="menu-item-156" class="menu-item "><a href="">Concrete Testing Lab Equipment</a></li>
                                                                    <li id="menu-item-1260" class="menu-item"><a href="">Cement Testing Lab Equipment</a></li>
                                                                    <li id="menu-item-157" class="menu-item "><a href="">Soil Testing lab Equipment</a></li>
                                                                    <li id="menu-item-158" class="menu-item "><a href="">Bitumen / Aspahlt testing Lab Equipment</a></li>
                                                                    <li id="menu-item-176" class="menu-item "><a href="">Aggregate Testing Lab Equipment</a></li>
                                                                    <li id="menu-item-1261" class="menu-item"><a href="">Rock Testing Lab Equipment</a></li>
                                                                    <li id="menu-item-179" class="menu-item "><a href="">Lab Equipment and Accessories</a></li>
                                                                    <li id="menu-item-1262" class="menu-item"><a href="">Steel Testing Lab Equipment</a></li>
                                                                    <li id="menu-item-177" class="menu-item "><a href="">Survey Instruments and Accessories</a></li>
                                                                    <li id="menu-item-178" class="menu-item "><a href="">Environmental Engineering Lab Equipment</a></li>
                                                                    <li id="menu-item-358" class="menu-item "><a href="">Structural Engineering Lab Equipment</a></li>
                                                                    <li id="menu-item-1115" class="menu-item"><a href="">Non Destructive Testing Equipment</a></li>
                                                                </ul>
                                                            </li>
                                                            <li id="menu-item-153" class="menu-item"><a href="">Mechanical Engineering Lab Equipment</a>
                                                                <ul class="sub-menu">
                                                                    <li id="menu-item-182" class="menu-item "><a href="">Workshop Tools, Machines and Accessories</a></li>
                                                                    <li id="menu-item-180" class="menu-item "><a href="">Materials Testing Lab Equipment</a></li>
                                                                    <li id="menu-item-193" class="menu-item "><a href="">Applied Mechanics Lab Equipment</a></li>
                                                                    <li id="menu-item-181" class="menu-item "><a href="">Fluid Mechanics Lab Equipment</a></li>
                                                                    <li id="menu-item-183" class="menu-item "><a href="">Tourbo Machinery Lab Equipment</a></li>
                                                                    <li id="menu-item-211" class="menu-item "><a href="">Thermal Engineering lab Equipment</a></li>
                                                                    <li id="menu-item-203" class="menu-item "><a href="">Automobile Engineering Lab Equipment</a></li>
                                                                    <li id="menu-item-191" class="menu-item "><a href="">Heat and Mass Transfer Lab Equipment</a></li>
                                                                    <li id="menu-item-192" class="menu-item "><a href="">Dynamics of Machine Lab Equipment</a></li>
                                                                    <li id="menu-item-1156" class="menu-item"><a href="">Refrigeration and Air conditioning lab equipment</a></li>
                                                                    <li id="menu-item-201" class="menu-item "><a href="">Measurement and Instrumentation Lab Equipment</a></li>
                                                                    <li id="menu-item-202" class="menu-item "><a href="">CAD and CAM Laboratory Equipment</a></li>
                                                                    <li id="menu-item-212" class="menu-item "><a href="">Robotics and Mechatronics lab equipment</a></li>
                                                                    <li id="menu-item-213" class="menu-item "><a href="">Engineering Models, Charts and Accessories</a></li>
                                                                    <li id="menu-item-2023" class="menu-item"><a href="">Fuel Testing Lab Equipment</a></li>
                                                                </ul>
                                                            </li>
                                                            <li id="menu-item-154" class="menu-item"><a href="">Electrical Engineering Lab Equipment</a>
                                                                <ul class="sub-menu">
                                                                    <li id="menu-item-264" class="menu-item "><a href="">Basic Elcrical Engineering lab Equipment</a></li>
                                                                    <li id="menu-item-255" class="menu-item "><a href="">Electrical Machines and Drives Lab</a></li>
                                                                    <li id="menu-item-248" class="menu-item "><a href="">Renewable Energy Lab Equipment</a></li>
                                                                    <li id="menu-item-266" class="menu-item "><a href="">Scada Lab Equipment</a></li>
                                                                    <li id="menu-item-265" class="menu-item "><a href="">High Voltage Lab Equipment</a></li>
                                                                </ul>
                                                            </li>
                                                            <li id="menu-item-155" class="menu-item"><a href="">Electronics and Communication Engineering Lab Equipment</a>
                                                                <ul class="sub-menu">
                                                                    <li id="menu-item-220" class="menu-item"><a href="">Digital Measuring Instruments</a></li>
                                                                    <li id="menu-item-244" class="menu-item"><a href="">PCB Design Lab Equipment</a></li>
                                                                    <li id="menu-item-221" class="menu-item"><a href="">Analog and Digital Trainer</a></li>
                                                                    <li id="menu-item-235" class="menu-item"><a href="">Communication Trainer</a></li>
                                                                    <li id="menu-item-236" class="menu-item"><a href="">Microprocessor Trainer</a></li>
                                                                    <li id="menu-item-237" class="menu-item"><a href="">VLSI and Embedded Technology trainer</a></li>
                                                                    <li id="menu-item-238" class="menu-item"><a href="">Power Electronics Lab Equipment</a></li>
                                                                    <li id="menu-item-239" class="menu-item"><a href="">Microwave Engineering Lab Equipments</a></li>
                                                                    <li id="menu-item-240" class="menu-item"><a href="">Instrumentation Control Engineering Lab Equipment</a></li>
                                                                </ul>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                    <li id="menu-item-288" class="menu-item"><a href="">Downloads</a>
                                                        <ul class="sub-menu">
                                                            <li id="menu-item-289" class="menu-item "><a href="">Product Catalogs</a>
                                                                <ul class="sub-menu">
                                                                    <li id="menu-item-292" class="menu-item "><a href="">Civil Engineering Catalog</a></li>
                                                                    <li id="menu-item-293" class="menu-item "><a href="">Mechanical Engineering catalog</a></li>
                                                                    <li id="menu-item-294" class="menu-item "><a href="">Electrical Engineering Catalog</a></li>
                                                                    <li id="menu-item-316" class="menu-item "><a href="">Electronics and Telecommunication Engineering Catalog</a></li>
                                                                </ul>
                                                            </li>
                                                            <li id="menu-item-290" class="menu-item"><a href="">Laboratory Manuals</a>
                                                                <ul class="sub-menu">
                                                                    <li id="menu-item-317" class="menu-item"><a href="">Civil Enineering Lab Manuals</a></li>
                                                                    <li id="menu-item-318" class="menu-item"><a href="">Mechanical Engineering Lab Manuals</a></li>
                                                                    <li id="menu-item-319" class="menu-item"><a href="">Electrical Engineering Lab Manuals</a></li>
                                                                    <li id="menu-item-320" class="menu-item"><a href="">Electronics and Telecommunication Engineering Manuals</a></li>
                                                                </ul>
                                                            </li>
                                                            <li id="menu-item-291" class="menu-item"><a href="">Equipment List</a>
                                                                <ul class="sub-menu">
                                                                    <li id="menu-item-321" class="menu-item"><a href="">Civil Enineering Lab Equipment List</a></li>
                                                                    <li id="menu-item-322" class="menu-item"><a href="">Mechanical Engineering Lab Equipment List</a></li>
                                                                    <li id="menu-item-323" class="menu-item"><a href="">Electrical Engineering Lab Equipment List</a></li>
                                                                    <li id="menu-item-324" class="menu-item"><a href="">Electronics and Telecommunication Engineering Equipment List</a></li>
                                                                </ul>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                    <li id="menu-item-325" class="menu-item"><a href="">Clients</a>
                                                        <ul class="sub-menu">
                                                            <li id="menu-item-46846" class="menu-item"><a href="">GEM Items</a></li>
                                                            <li id="menu-item-49023" class="menu-item"><a href="">GEM Items 2</a></li>
                                                            <li id="menu-item-341" class="menu-item"><a href="">GEM Items 3</a></li>
                                                            <li id="menu-item-342" class="menu-item"><a href="">Engineering Colleges</a></li>
                                                            <li id="menu-item-343" class="menu-item"><a href="">Universities</a></li>
                                                            <li id="menu-item-344" class="menu-item"><a href="">Ministries</a></li>
                                                            <li id="menu-item-345" class="menu-item"><a href="">Vocational and Polytechnic Institutes</a></li>
                                                            <li id="menu-item-347" class="menu-item"><a href="">Worldwide Export</a></li>
                                                        </ul>
                                                    </li>
                                                    <li id="menu-item-286" class="menu-item"><a href="">Contact us</a></li>
                                                    <li id="menu-item-287" class="menu-item"><a href="">Enquiry</a></li>
                                                </ul>
                                            </div>
                                        </nav>
                                        <!-- #site-navigation -->
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                                <ul class="search-consult col-md-1 col-1 m-0">
                                    <li class="search-box">
                                        <span><i class="fas fa-search"></i></span>
                                    </li>
                                </ul>
                                <div class="serach_outer">
                                    <div class="closepop"><i class="far fa-window-close"></i></div>
                                    <div class="serach_inner search_popup">
                                        <form role="search" method="get" class="search-form serach-page" action="https://vlutech.com/">
                                            <label>
        <input type="search" class="search-field" placeholder="Search &hellip;" value="" name="s">
    </label>
                                            <input type="submit" class="search-submit" value="Search">
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    @section('container')
    @show

    <div class="clearfix"></div>
    <div class="outer-footer">
        <div id="footer">
            <div id="footer_box" class="darkbox">
                <div class="container">
                    <div class="container footer-top">
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                <div class="footer-top-col">
                                    <h3>Call us no:</h3>
                                    <p><span>Office Telephone: </span>+91-9971077233</p>
                                    <p><span>Office Mobile: </span>+91-8595806705</p>
                                </div>
                            </div>

                            <div class="col-lg-4 col-md-4 col-sm-12">
                                <div class="footer-top-col">
                                    <h3>Come visit us:</h3>
                                    <p>Sun LabTek Equipments (I) Pvt. Ltd. B-3A, Shiv Shakti Complex, East Vinod Nagar, New Delhi-110091, India</p>
                                </div>
                            </div>

                            <div class="col-lg-4 col-md-4 col-sm-12">
                                <div class="footer-top-col">
                                    <h3>Send a message</h3>
                                    <p><span>Email: </span>info@sunlabtech.com</p>
                                    <p><span>Inquiries: </span>&#115;a&#108;&#101;s&#064;&#115;unl&#097;&#098;&#116;ech.c&#111;&#109;</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="container footer-cols">
                    <div class="row">
                        <div class="footer_hide">
                        </div>
                        <div class="col-lg-6 col-sm-6">
                            <aside id="text-4" class="widget widget_text">
                                <h3 class="widget-title">Civil Engineering Lab Equipment</h3>
                                <div class="textwidget">
                                    <ul>
                                        <li><a href="">Concrete testing lab Equipment </a></li>
                                        <li><a href="">Cement Testing Lab Equipment</a></li>
                                        <li><a href="">Soil Testing lab equipment</a></li>
                                        <li><a href="">Bitumen Testing lab equipment</a></li>
                                        <li><a href="">Aggregate testing lab equipment</a></li>
                                        <li><a href="">Steel Testing lab equipment</a></li>
                                        <li><a href="">Rock testing lab equipment</a></li>
                                    </ul>
                                </div>
                            </aside>
                        </div>
                        <div class="col-lg-6 col-sm-6">
                            <aside id="text-3" class="widget widget_text">
                                <h3 class="widget-title">Mechanical Lab Equipment</h3>
                                <div class="textwidget">
                                    <ul>
                                        <li><a href="">Mechanical Engineering Lab Equipment</a></li>
                                        <li><a href="">Materials Testing Lab Equipment</a></li>
                                        <li><a href="">Workshop Machines and Tools</a></li>
                                        <li><a href="">Applied mechanics lab equipments</a></li>
                                        <li><a href="">Tourbo Machinery Lab Equipment</a></li>
                                        <li><a href="">Fluid Mechanics Lab Equipment</a></li>
                                        <li><a href="">Thermal Engineering lab Equipment</a></li>
                                    </ul>
                                </div>
                            </aside>
                        </div>
                        <div class="footer_hide">
                        </div>
                    </div>
                </div>
                <!-- .container -->
            </div>
            <!-- #footer_box -->
        </div>
        <div class="copyright">
            <div class="container">
                <div class="row main_sociobox">
                    <div class="col-md-6 col-sm-12">
                        <p>www.sunlabtech.com 2020 | All Rights Reserved.</p>
                    </div>
                    <div class="col-md-6 col-sm-12">
                        <div class="socialbox">
                            <a class="twitter" href="https://twitter.com/" target="_blank"><i class="fab fa-twitter align-middle" aria-hidden="true"></i></a>
                            <a class="insta" href="https://www.instagram.com" target="_blank"><i class="fab fa-instagram align-middle" aria-hidden="true"></i></a>
                            <a class="facebook" href="https://www.facebook.com/" target="_blank"><i class="fab fa-facebook-f align-middle " aria-hidden="true"></i></a>
                            <a class="youtube" href="https://www.youtube.com" target="_blank"><i class="fab fa-youtube align-middle" aria-hidden="true"></i></a>
                            <a class="pintrest" href="https://www.pinterest.com/" target="_blank"><i class="fab fa-pinterest-p align-middle " aria-hidden="true"></i></a>
                            <a class="linkedin" href="https://www.linkedin.com" target="_blank"><i class="fab fa-linkedin-in align-middle" aria-hidden="true"></i></a>
                            <a class="tumbler" href="https://www.tumblr.com/" target="_blank"><i class="fab fa-tumblr align-middle" aria-hidden="true"></i></a>
                            <a class="gplus" href="https://plus.google.com/" target="_blank"><i class="fab fa-google-plus-g align-middle" aria-hidden="true"></i></a>
                            <a class="flicker" href="https://www.flickr.com/" target="_blank"><i class="fab fa-flickr align-middle " aria-hidden="true"></i></a>
                            <a class="vk" href="https://vk.com/" target="_blank"><i class="fab fa-vk align-middle " aria-hidden="true"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>   
</body>
</html>
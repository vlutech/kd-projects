<?php $__env->startSection('container'); ?>

   

    <section id="aa-slider">
    <div class="aa-slider-area">
      <div id="sequence" class="seq">
        <div class="seq-screen">
          <ul class="seq-canvas">
            <!-- single slide item -->
            <li>
              <div class="seq-model">
                <img data-seq src="<?php echo e(asset('site-assets/img/CIVIL-ENGINEERING-LABORATORY-EQUIPMENT.jpg')); ?>" alt="Men slide img" />
              </div>
              <!-- <div class="seq-title">
               <span data-seq>Save Up to 75% Off</span>                
                <h2 data-seq>Men Collection</h2>                
                <p data-seq>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minus, illum.</p>
                <a data-seq href="#" class="aa-shop-now-btn aa-secondary-btn">SHOP NOW</a>
              </div> -->
            </li>
            <!-- single slide item -->
            <li>
              <div class="seq-model">
                <img data-seq src="<?php echo e(asset('site-assets/img/LABORATORY-EQUIPMENT-CIVIL-ENGINEERING.jpg')); ?>" alt="Wristwatch slide img" />
              </div>
              <!-- <div class="seq-title">
                <span data-seq>Save Up to 40% Off</span>                
                <h2 data-seq>Wristwatch Collection</h2>                
                <p data-seq>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minus, illum.</p>
                <a data-seq href="#" class="aa-shop-now-btn aa-secondary-btn">SHOP NOW</a>
              </div> -->
            </li>
            <!-- single slide item -->
            <li>
              <div class="seq-model">
                <img data-seq src="<?php echo e(asset('site-assets/img/MECHANICAL-ENGINEERING-LABORATORY-EQUIPMENT.jpg')); ?>" alt="Women Jeans slide img" />
              </div>
              <!-- <div class="seq-title">
                <span data-seq>Save Up to 75% Off</span>                
                <h2 data-seq>Jeans Collection</h2>                
                <p data-seq>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minus, illum.</p>
                <a data-seq href="#" class="aa-shop-now-btn aa-secondary-btn">SHOP NOW</a>
              </div> -->
            </li>
            <!-- single slide item -->           
                       
          </ul>
        </div>
        <!-- slider navigation btn -->
        <fieldset class="seq-nav" aria-controls="sequence" aria-label="Slider buttons">
          <a type="button" class="seq-prev" aria-label="Previous"><span class="fa fa-angle-left"></span></a>
          <a type="button" class="seq-next" aria-label="Next"><span class="fa fa-angle-right"></span></a>
        </fieldset>
      </div>
    </div>
  </section>


    <section id="consult_sec">
        <div class="container-fluid">
            <div class="row consult_inner">
                <div class="col-md-4 consult_box_outer">
                    <div class="consult_box  mt-4 mb-4">
                        <!-- <div class="col-md-4 consult_title"> -->
                            <div class="mid-content">
                                <p><i class="fas fa-phone-volume"></i>+91-9971077233</p>
                            </div>
                        <!-- </div> -->
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="consult_content mt-4 mb-4 pl-3">
                        <div class="consult_inner row">
                            <div class="consult_wrapper col-md-8">
                                <h6 class="pt-0 pb-0 text-uppercase">Lab Equipment Company</h6>
                                <p class="">We are manufcaturer and solution company for engineering educational laboratory and quality testing equipment.</p>
                            </div>

                            <div class="col-md-4 bth_consult">
                                <a class="btn btn-outline-secondary" href="https://vlutech.com">Click and connect</a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </section>
    <section id="welcome">
        <div class="inner_sec">
            <div class="container">
                <div class="row">
                    <div class="welcome_img col-lg-4 col-md-6 col-sm-6">
                        <img src="<?php echo e(asset('site-assets/img/Civil-Engineer.jpg')); ?>" alt="">
                    </div>
                    <div class="col-lg-8 col-md-12 col-sm-12">
                        <div class="welcome-content">
                            <div class="welcome-heading">
                                <div class="row">
                                    <div class="col-md-10">
                                        <h2><small>OVER 25 YEARS OF EXPERIENCE</small>WELCOME TO LabTek!</h2>
                                    </div>
                                    <div class="col-md-2">
                                        <img src="<?php echo e(asset('site-assets/img/welcome-icon.png')); ?>" alt="">
                                    </div>
                                </div>
                            </div>
                            <p>LabTek has a selection of more than 500 mechanical engineering and 800 civil engineering equipments and test rigs. With customers spread across the globe, LabTek is regarded as premier supplier of reliable, high quality and
                                competitively priced products. We provide Turnkey solution for establishing mechanical and civil engineering laboratory with state of the art technology and solution.</p>
                            <a href="">Discover More</a>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </section>

    <section id="our_records" style="background-image:url(&#039;https://sunlabtech.com/wp-content/themes/alt-construction-estate-pro/assets/images/footerbg.jpg&#039;)">
        <div class="container">
            <div class="owl-carousel counter-box">
                <div class="row active">
                    <div class="col-md-4 col-4 counter-icon">
                        <img src="<?php echo e(asset('site-assets/img/Untitled-5.png')); ?>" alt="">
                    </div>
                    <div class="col-md-8 col-8">
                        <div class="radius">
                            <h4 class="count">3500</h4>
                        </div>
                        <div class="radius-para">
                            <p>Lab Equipment</p>
                        </div>
                    </div>
                </div>
                <div class="row ">
                    <div class="col-md-4 col-4 counter-icon">
                        <img src="<?php echo e(asset('site-assets/img/Untitled-6.png')); ?>" alt="">
                    </div>
                    <div class="col-md-8 col-8">
                        <div class="radius">
                            <h4 class="count">1500</h4>
                        </div>
                        <div class="radius-para">
                            <p>Valued Customers</p>
                        </div>
                    </div>
                </div>
                <div class="row ">
                    <div class="col-md-4 col-4 counter-icon">
                        <img src="<?php echo e(asset('site-assets/img/Staff.png')); ?>" alt="">
                    </div>
                    <div class="col-md-8 col-8">
                        <div class="radius">
                            <h4 class="count">120</h4>
                        </div>
                        <div class="radius-para">
                            <p>Dedicated Staff</p>
                        </div>
                    </div>
                </div>
                <div class="row ">
                    <div class="col-md-4 col-4 counter-icon">
                        <img src="<?php echo e(asset('site-assets/img/Global.png')); ?>" alt="">
                    </div>
                    <div class="col-md-8 col-8">
                        <div class="radius">
                            <h4 class="count">45</h4>
                        </div>
                        <div class="radius-para">
                            <p>Exporting Globally</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
    </section>
    <section id="services_tab">
        <div class="inner_sec">
            <div class="container">
                <div class="welcome-heading">
                    <div class="row">
                        <div class="col-md-11">
                            <h2><small>Services we are offerring</small>OUR SERVICES</h2>
                        </div>
                        <div class="col-md-1">
                            <img src="<?php echo e(asset('site-assets/img/services-icon.png')); ?>" alt="">
                        </div>
                    </div>
                </div>

                <div class="about-inner">
                    <ul class="nav nav-pills nav-justified row">
                        <li class="nav-item col-md-2">
                            <a class="nav-link active" href="#services_area1" role="tab" data-toggle="tab">Concrete Test Equipment</a>
                        </li>
                        <li class="nav-item col-md-2">
                            <a class="nav-link " href="#services_area2" role="tab" data-toggle="tab">Soil Test Equipment</a>
                        </li>
                        <li class="nav-item col-md-2">
                            <a class="nav-link " href="#services_area3" role="tab" data-toggle="tab">Bitumen Test Equipment</a>
                        </li>
                        <li class="nav-item col-md-2">
                            <a class="nav-link " href="#services_area4" role="tab" data-toggle="tab">Aggregate Test Equipment</a>
                        </li>
                        <li class="nav-item col-md-2">
                            <a class="nav-link " href="#services_area5" role="tab" data-toggle="tab">Cement Test Equipment</a>
                        </li>
                        <li class="nav-item col-md-2">
                            <a class="nav-link " href="#services_area6" role="tab" data-toggle="tab">Steel Test Equipment</a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div role="tabpanel" class="outer_tab tab-pane fade in active show" id="services_area1">
                            <div class="row">
                                <div class="col-md-7 tab-content">
                                    <h3>Concrete Test Equipment</h3>
                                    <div class="services-editor">
                                        <p>We supply varieties of high quality and all international standard testing equipment and accessories to test in Concrete testing lab equipment or concrete testing machines, building and civil engineering laboratory
                                            equipment and accessories.</p>
                                    </div>
                                    <div class="details-box">
                                        <div class="details-box-content">
                                            <div class="row">
                                                <div class="col-md-4 col-sm-4">
                                                    <div><i class="fas fa-edit"></i>
                                                        <Strong>1.Purchase</Strong>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-4">
                                                    <div><i class="fas fa-pencil-alt"></i>
                                                        <Strong>2.Install</Strong>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-4">
                                                    <div><i class="fas fa-building"></i>
                                                        <Strong>3.Training</Strong>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="get-btn">
                                        <a href="">Get In Touch</a>
                                    </div>
                                </div>
                                <div class="offset-md-1 col-md-4">
                                    <div class="feature-img-height">
                                        <img class="feature-img mt-3 mb-3" src="<?php echo e(asset('site-assets/img/Concrete-1.jpg')); ?>" alt="Image" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div role="tabpanel" class="outer_tab tab-pane fade " id="services_area2">
                            <div class="row">
                                <div class="col-md-7 tab-content">
                                    <h3>Soil Test Equipment</h3>
                                    <div class="services-editor">
                                        <p>We manufacture the best quality equipment related to Determination of moisture content, Determination of specific gravity, Field density test, Grain size analysis a.sieve analysis, hydrometer analysis, Determination
                                            of consistency limits.</p>
                                    </div>
                                    <div class="details-box">
                                        <div class="details-box-content">
                                            <div class="row">
                                                <div class="col-md-4 col-sm-4">
                                                    <div><i class="fas fa-edit"></i>
                                                        <Strong>1.Plan</Strong>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-4">
                                                    <div><i class="fas fa-pencil-alt"></i>
                                                        <Strong>2.Install</Strong>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-4">
                                                    <div><i class="fas fa-building"></i>
                                                        <Strong>3.Calibration</Strong>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="get-btn">
                                        <a href="">Get In Touch</a>
                                    </div>
                                </div>
                                <div class="offset-md-1 col-md-4">
                                    <div class="feature-img-height">
                                        <img class="feature-img mt-3 mb-3" src="<?php echo e(asset('site-assets/img/Soil-ab.jpg')); ?>" alt="Image" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div role="tabpanel" class="outer_tab tab-pane fade " id="services_area3">
                            <div class="row">
                                <div class="col-md-7 tab-content">
                                    <h3>Bitumen Test Equipment</h3>
                                    <div class="services-editor">
                                        <p>Bitumen Testing lab equipment; Asphalt testing lab equipment, Transportation engineering lab equipment, Road testing instruments, building and civil engineering laboratory equipment and accessories. We are supplying
                                            the equipment to quality testing laboratories civil builders, civil contractors, Engineering colleges, Universities and Polytechnics.</p>
                                    </div>
                                    <div class="details-box">
                                        <div class="details-box-content">
                                            <div class="row">
                                                <div class="col-md-4 col-sm-4">
                                                    <div><i class="fas fa-edit"></i>
                                                        <Strong>1.Plan</Strong>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-4">
                                                    <div><i class="fas fa-pencil-alt"></i>
                                                        <Strong>2.Purchase</Strong>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-4">
                                                    <div><i class="fas fa-building"></i>
                                                        <Strong>3.Install</Strong>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="get-btn">
                                        <a href="">Get In Touch</a>
                                    </div>
                                </div>
                                <div class="offset-md-1 col-md-4">
                                    <div class="feature-img-height">
                                        <img class="feature-img mt-3 mb-3" src="<?php echo e(asset('site-assets/img/Bitumen-BB.jpg')); ?>" alt="Image" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div role="tabpanel" class="outer_tab tab-pane fade " id="services_area4">
                            <div class="row">
                                <div class="col-md-7 tab-content">
                                    <h3>Aggregate Test Equipment</h3>
                                    <div class="services-editor">
                                        <p>Aggregate Testing Lab Equipment, that comprises of Sample Splitter, Aggregate Crushing Value Apparatus, Aggregate Impact Tester With Blow Counter, Los Angeles Abrasion Testing Machine, Dorry Abrasion Testing Machine,
                                            Devel Attrition Tester, Thickness Gauge, Length Gauge.</p>
                                    </div>
                                    <div class="details-box">
                                        <div class="details-box-content">
                                            <div class="row">
                                                <div class="col-md-4 col-sm-4">
                                                    <div><i class="fas fa-edit"></i>
                                                        <Strong>1.Purchase</Strong>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-4">
                                                    <div><i class="fas fa-pencil-alt"></i>
                                                        <Strong>2.Calibration</Strong>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-4">
                                                    <div><i class="fas fa-building"></i>
                                                        <Strong>3.Training</Strong>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="get-btn">
                                        <a href="">Get In Touch</a>
                                    </div>
                                </div>
                                <div class="offset-md-1 col-md-4">
                                    <div class="feature-img-height">
                                        <img class="feature-img mt-3 mb-3" src="<?php echo e(asset('site-assets/img/Aggregate-bb.jpg')); ?>" alt="Image" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div role="tabpanel" class="outer_tab tab-pane fade " id="services_area5">
                            <div class="row">
                                <div class="col-md-7 tab-content">
                                    <h3>Cement Test Equipment</h3>
                                    <div class="services-editor">
                                        <p>We manufacture the best quality Cement samplers, Le Chatelier flask, Le Chatelier moulds, Length comparator, Hydraulic shrinkage mould, High pressure Cement Autoclave, Blaine fineness apparatus, Standard Vicat apparatus,
                                            Flow tables for mortar and building lime, Air content meters, Flow cone apparatus, Marsh funnel viscometer, Vibrating machine, Cement curing cabinet as per the international standards and specifications.</p>
                                    </div>
                                    <div class="details-box">
                                        <div class="details-box-content">
                                            <div class="row">
                                                <div class="col-md-4 col-sm-4">
                                                    <div><i class="fas fa-edit"></i>
                                                        <Strong>1.Plan</Strong>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-4">
                                                    <div><i class="fas fa-pencil-alt"></i>
                                                        <Strong>2.Design</Strong>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-4">
                                                    <div><i class="fas fa-building"></i>
                                                        <Strong>3.Delivery</Strong>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="get-btn">
                                        <a href="">Get In Touch</a>
                                    </div>
                                </div>
                                <div class="offset-md-1 col-md-4">
                                    <div class="feature-img-height">
                                        <img class="feature-img mt-3 mb-3" src="<?php echo e(asset('site-assets/img/Cement-bb.jpg')); ?>" alt="Image" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div role="tabpanel" class="outer_tab tab-pane fade " id="services_area6">
                            <div class="row">
                                <div class="col-md-7 tab-content">
                                    <h3>Steel Test Equipment</h3>
                                    <div class="services-editor">
                                        <p>LabTek is manufacturer, supplier, solution provider and exporter of Aggregate Testing Lab Equipment. We are supplying the equipment to quality testing laboratories to civil builders, civil contractors, Engineering
                                            colleges, Universities and Polytechnics. We manufacture the best quality equipment related to Steel Testing Lab Equipment.</p>
                                    </div>
                                    <div class="details-box">
                                        <div class="details-box-content">
                                            <div class="row">
                                                <div class="col-md-4 col-sm-4">
                                                    <div><i class="fas fa-edit"></i>
                                                        <Strong>1.Plan</Strong>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-4">
                                                    <div><i class="fas fa-pencil-alt"></i>
                                                        <Strong>2.Purchase</Strong>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-4">
                                                    <div><i class="fas fa-building"></i>
                                                        <Strong>3.Delivery</Strong>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="get-btn">
                                        <a href="">Get In Touch</a>
                                    </div>
                                </div>
                                <div class="offset-md-1 col-md-4">
                                    <div class="feature-img-height">
                                        <img class="feature-img mt-3 mb-3" src="<?php echo e(asset('site-assets/img/Steel-BB.jpg')); ?>" alt="Image" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </section>

    <section id="project" style="background-image:url(&#039;https://sunlabtech.com/wp-content/uploads/2021/07/Back.jpg&#039;)">
        <div class="container">
            <div class="about-inner">
                <div class="welcome-heading">
                    <div class="row">
                        <div class="col-md-11">
                            <h2><small>We honoured to have these amazing products</small>OUR PRODUCTS</h2>
                        </div>
                        <div class="col-md-1">
                            <img src="<?php echo e(asset('site-assets/img/project-icon.png')); ?>" alt="">
                        </div>
                    </div>
                </div>
                <div class="row tab-wrap">
                    <div class="col-md-1 link-bg p-0">
                        <!-- <ul class="nav nav-pills nav-justified">
                            <li class="nav-item">
                                <a class="nav-link active" href="#project1" role="tab" data-toggle="tab"><img src="https://sunlabtech.com/wp-content/uploads/2020/10/Civil.jpg" alt=""> <p class="project_cat_title">Civil Engineering Lab Equipment</p></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link " href="#project2" role="tab" data-toggle="tab"><img src="https://sunlabtech.com/wp-content/uploads/2020/10/mechanical.png" alt=""> <p class="project_cat_title">Mechanical Engineering</p></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link " href="#project3" role="tab" data-toggle="tab"><img src="https://sunlabtech.com/wp-content/uploads/2020/10/Electrical.png" alt=""> <p class="project_cat_title">Electrical Engineering</p></a>
                            </li>
                        </ul> -->
                    </div>
                    <div class="col-md-11">
                        <div class="tab-content">
                            <div role="tabpanel" class="outer_tab tab-pane fade in active show" id="project1">
                                <div class="row">
                                    <div class="col-lg-8 col-md-12 1">
                                        <div class="project-img">
                                            <img src="<?php echo e(asset('site-assets/img/Civil-Engineering-lab-equipment.jpg')); ?>" alt="" />
                                        </div>
                                        <div class="project-title mb-0">
                                            <h3><a href="">Civil Engineering Testing Equipment</a></h3>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12 col-sm-12 p-0">
                                        <div class="col-lg-12 col-md-12 2">
                                            <div class="project-img">
                                                <img src="<?php echo e(asset('site-assets/img/Concrete-testing-lab-equipment.jpg')); ?>" alt="" />
                                            </div>
                                            <div class="project-title">
                                                <h3><a href="">Concrete Testing Machines</a></h3>
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-md-12 3">
                                            <div class="project-img">
                                                <img src="<?php echo e(asset('site-assets/img/Bitumen-testing-lab-equipment.jpg')); ?>" alt="" />
                                            </div>
                                            <div class="project-title">
                                                <h3><a href="">Bitumen Testing Machines</a></h3>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div role="tabpanel" class="outer_tab tab-pane fade " id="project2">
                                <div class="row">
                                    <div class="col-lg-8 col-md-12 1">
                                        <div class="project-img">
                                            <img src="<?php echo e(asset('site-assets/img/SOM1.jpg')); ?>" alt="" />
                                        </div>
                                        <div class="project-title mb-0">
                                            <h3><a href="">Mechanical Engineering Laboratory Equipment</a></h3>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12 col-sm-12 p-0">
                                        <div class="col-lg-12 col-md-12 2">
                                            <div class="project-img">
                                                <img src="<?php echo e(asset('site-assets/img/Soil-Test-equipment.jpg')); ?>" alt="" />
                                            </div>
                                            <div class="project-title">
                                                <h3><a href="">Soil Testing Instruments</a></h3>
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-md-12 3">
                                            <div class="project-img">
                                                <img src="<?php echo e(asset('site-assets/img/Laboratory-instruments.jpg')); ?>" alt="" />
                                            </div>
                                            <div class="project-title">
                                                <h3><a href="">Laboratory Instruments</a></h3>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div role="tabpanel" class="outer_tab tab-pane fade " id="project3">
                                <div class="row">
                                    <div class="col-lg-12 col-md-12 1">
                                        <h5 class="text-center">Projects Not Added</h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </section>

    <section id="choosevideo">
        <div class="row m-0">
            <div class="col-lg-6 p-0">
                <section id="why-choose-us">
                    <div class="inner_sec">
                        <div class="">
                            <div class="about-inner">
                                <div class="welcome-heading">
                                    <div class="row">
                                        <div class="col-md-10">
                                            <h2><small>See Our latest Features!</small>WHY CHOOSE US</h2>
                                        </div>
                                        <div class="col-md-2">
                                            <img src="<?php echo e(asset('site-assets/img/choose-icon.png')); ?>" alt="">
                                        </div>
                                    </div>
                                </div>
                                <div class="why-choose-box">
                                    <div class="row">
                                        <div class="col-md-2 col-3">
                                            <div class="choose-box-icon">
                                                <i class="far fa-building"></i>
                                            </div>
                                        </div>
                                        <div class="col-md-10 col-9">
                                            <div class="choose-box-content">
                                                <h4>You Trust Us</h4>
                                                <p>We are more than decade old company and delivering.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-2 col-3">
                                            <div class="choose-box-icon">
                                                <i class="far fa-building"></i>
                                            </div>
                                        </div>
                                        <div class="col-md-10 col-9">
                                            <div class="choose-box-content">
                                                <h4>We Innovate</h4>
                                                <p>Our innovation has put smiles on customer&#039;s face.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-2 col-3">
                                            <div class="choose-box-icon">
                                                <i class="far fa-building"></i>
                                            </div>
                                        </div>
                                        <div class="col-md-10 col-9">
                                            <div class="choose-box-content">
                                                <h4>We deliver</h4>
                                                <p>We create best products with ease of use to customers.</p>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </section>
            </div>
            <div class="col-lg-6 p-0">
                <section id="video">
                    <iframe width="100%" height="350" src="https://www.youtube.com/embed/S0aV3gM8_60" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                </section>
            </div>
        </div>
    </section>
    <section id="testimonials">
        <div class="container">
            <div class="welcome-heading">
                <div class="row">
                    <div class="col-md-11">
                        <h2><small>What Our Clients Say</small>TESTIMONIALS</h2>
                    </div>
                    <div class="col-md-1">
                        <img src="<?php echo e(asset('site-assets/img/testimonial-icon.png')); ?>" alt="">
                    </div>
                </div>
            </div>
            <div class="owl-carousel">
                <div class="active">
                    <div class="testimonial_box w-100 mb-3">
                        <div class="content_box w-100">
                            <div class="short_text pb-3">Sun LabTek Equipments India Private Limited is supplying best quality equipment in all the engineering branches and faculties and has set up almost all the</div>
                        </div>
                        <div class="image-box media">
                            <img class="d-flex align-self-center mr-3" src="<?php echo e(asset('site-assets/img/Amity.jpg')); ?>">
                            <div class="testimonial-box media-body">
                                <h4 class="testimonial_name"><a href="">Amity University</a> <small>Vice President</small></h4>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="">
                    <div class="testimonial_box w-100 mb-3">
                        <div class="content_box w-100">
                            <div class="short_text pb-3">We at Manipal University, Malaysia had purchased Civil and Mechanical Engineering Laboratory equipments from Sun LabTek Equipments India Private Limited in the year 2012, we</div>
                        </div>
                        <div class="image-box media">
                            <img class="d-flex align-self-center mr-3" src="<?php echo e(asset('site-assets/img/mani.jpg')); ?>">
                            <div class="testimonial-box media-body">
                                <h4 class="testimonial_name"><a href="">Manipal University</a> <small>Director</small></h4>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="">
                    <div class="testimonial_box w-100 mb-3">
                        <div class="content_box w-100">
                            <div class="short_text pb-3">We have visited and done the pre-inspection at the factory of LabTek India, we found the world class equipment in Civil and Mechanical Engineering departments</div>
                        </div>
                        <div class="image-box media">
                            <img class="d-flex align-self-center mr-3" src="<?php echo e(asset('site-assets/img/MOEST.jpg')); ?>">
                            <div class="testimonial-box media-body">
                                <h4 class="testimonial_name"><a href="">MOEST Kenya</a> <small>Director</small></h4>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="">
                    <div class="testimonial_box w-100 mb-3">
                        <div class="content_box w-100">
                            <div class="short_text pb-3">We were delighted to purchase Advance Tilting flume apparatus from LabTek India, we hope the kind of technology and the impact of these technology can</div>
                        </div>
                        <div class="image-box media">
                            <img class="d-flex align-self-center mr-3" src="<?php echo e(asset('site-assets/img/hwm.jpg')); ?>">
                            <div class="testimonial-box media-body">
                                <h4 class="testimonial_name"><a href="">HWM</a> <small>Executive engineer</small></h4>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="">
                    <div class="testimonial_box w-100 mb-3">
                        <div class="content_box w-100">
                            <div class="short_text pb-3">We have established the chain of material quality testing laboratories for Concrete, Soil, Cement, Bitumen and steel across India at our Manufacturing plants, RMC plants</div>
                        </div>
                        <div class="image-box media">
                            <img class="d-flex align-self-center mr-3" src="<?php echo e(asset('site-assets/img/0-1.jpg')); ?>">
                            <div class="testimonial-box media-body">
                                <h4 class="testimonial_name"><a href="">Lafarge Cement</a> <small>Engineer</small></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="our_partners">
        <div class="container">
            <div class="client_inner">
                <div class="welcome-heading">
                    <div class="row">
                        <div class="col-md-11">
                            <h2><small>We honored to have these amazing partners.</small>OUR PARTNERS</h2>
                        </div>
                        <div class="col-md-1">
                            <img src="<?php echo e(asset('site-assets/img/partners-icon.png')); ?>" alt="">
                        </div>
                    </div>
                </div>
                <div class="owl-carousel">
                    <div class="client_inner">
                        <img class="feature-img mt-3 mb-3" src="<?php echo e(asset('site-assets/img/proceq-logo.jpg')); ?>" alt="Image" />
                    </div>
                    <div class="client_inner">
                        <img class="feature-img mt-3 mb-3" src="<?php echo e(asset('site-assets/img/mitutoyo-logo.jpg')); ?>" alt="Image" />
                    </div>
                    <div class="client_inner">
                        <img class="feature-img mt-3 mb-3" src="<?php echo e(asset('site-assets/img/Sokkia-Logo.jpg')); ?>" alt="Image" />
                    </div>
                    <div class="client_inner">
                        <img class="feature-img mt-3 mb-3" src="<?php echo e(asset('site-assets/img/Borosil-logo.jpg')); ?>" alt="Image" />
                    </div>
                    <div class="client_inner">
                        <img class="feature-img mt-3 mb-3" src="<?php echo e(asset('site-assets/img/Hanna-Logo.jpg')); ?>" alt="Image" />
                    </div>
                    <div class="client_inner">
                        <img class="feature-img mt-3 mb-3" src="<?php echo e(asset('site-assets/img/Shimadzu-logo.jpg')); ?>" alt="Image" />
                    </div>

                </div>
            </div>
        </div>
    </section>



    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
      <!-- Include all compiled plugins (below), or include individual files as needed -->
  <script src="<?php echo e(asset('site-assets/js/bootstrap.js')); ?>"></script>  
  <!-- SmartMenus jQuery plugin -->
  <script type="text/javascript" src="<?php echo e(asset('site-assets/js/jquery.smartmenus.js')); ?>"></script>
  <!-- SmartMenus jQuery Bootstrap Addon -->
  <script type="text/javascript" src="<?php echo e(asset('site-assets/js/jquery.smartmenus.bootstrap.js')); ?>"></script>  
  <!-- To Slider JS -->
  <script src="<?php echo e(asset('site-assets/js/sequence.js')); ?>"></script>
  <script src="<?php echo e(asset('site-assets/js/sequence-theme.modern-slide-in.js')); ?>"></script>  
  <!-- Product view slider -->
  <script type="text/javascript" src="<?php echo e(asset('site-assets/js/jquery.simpleGallery.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('site-assets/js/jquery.simpleLens.js')); ?>"></script>
  <!-- slick slider -->
  <script type="text/javascript" src="<?php echo e(asset('site-assets/js/slick.js')); ?>"></script>
  <!-- Price picker slider -->
  <script type="text/javascript" src="<?php echo e(asset('site-assets/js/nouislider.js')); ?>"></script>
  <!-- Custom js -->
  <script src="<?php echo e(asset('site-assets/js/custom.js')); ?>"></script> 


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sunlab\resources\views/welcome.blade.php ENDPATH**/ ?>